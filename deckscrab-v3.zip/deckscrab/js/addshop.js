/**
 * addshop.js — Multi-step business registration form
 */
const AddShopModule = (() => {
  let _step = 0;
  let _selSector = null;
  let _pinned = false;
  let _regMap = null;
  let _regMarker = null;
  let _photos = [null, null, null, null];
  let _prods = [];

  const SECTORS = [
    { e:'🛒', n:'Grocery',         g:'retail'    },
    { e:'🍛', n:'Restaurant',      g:'food'      },
    { e:'💊', n:'Pharmacy',        g:'health'    },
    { e:'👗', n:'Clothes',         g:'retail'    },
    { e:'📱', n:'Electronics',     g:'retail'    },
    { e:'🔩', n:'Hardware',        g:'retail'    },
    { e:'🥐', n:'Bakery',          g:'food'      },
    { e:'🧵', n:'Tailor',          g:'service'   },
    { e:'⚡', n:'Welder',          g:'service'   },
    { e:'🚿', n:'Plumber',         g:'service'   },
    { e:'🔌', n:'Electrician',     g:'service'   },
    { e:'🔧', n:'Mechanic',        g:'service'   },
    { e:'🪚', n:'Carpenter',       g:'service'   },
    { e:'🚗', n:'Taxi/Auto',       g:'service'   },
    { e:'💇', n:'Ladies Salon',    g:'beauty'    },
    { e:'✂️', n:"Men's Saloon",   g:'beauty'    },
    { e:'🏋️', n:'Gym',             g:'beauty'    },
    { e:'👨‍⚕️',n:'Doctor',          g:'health'    },
    { e:'🦷', n:'Dentist',         g:'health'    },
    { e:'🏥', n:'Hospital',        g:'health'    },
    { e:'🧪', n:'Diagnostic Lab',  g:'health'    },
    { e:'🏫', n:'School',          g:'education' },
    { e:'📖', n:'Tuition',         g:'education' },
    { e:'💻', n:'Computer Training',g:'education'},
    { e:'🏦', n:'Bank/ATM',        g:'finance'   },
    { e:'📊', n:'CA/Accountant',   g:'finance'   },
    { e:'⚖️', n:'Lawyer',          g:'finance'   },
    { e:'🏠', n:'Real Estate',     g:'finance'   },
    { e:'🛕', n:'Temple',          g:'religious' },
    { e:'⛪', n:'Church',           g:'religious' },
    { e:'🕌', n:'Mosque',           g:'religious' },
    { e:'🌾', n:'Agriculture',     g:'agri'      },
    { e:'🍎', n:'Fruits & Veg',    g:'retail'    },
    { e:'🥛', n:'Dairy',           g:'retail'    },
    { e:'🍲', n:'Biryani',         g:'food'      },
    { e:'☕', n:'Café',             g:'food'      },
    { e:'❄️', n:'AC Repair',       g:'service'   },
    { e:'📲', n:'Mobile Repair',   g:'service'   },
    { e:'📦', n:'Courier',         g:'service'   },
    { e:'🧱', n:'Building Mat.',   g:'retail'    },
    { e:'🏪', n:'Other Business',  g:'retail'    },
  ];

  function init() {
    _step = 0;
    _selSector = null;
    _pinned = false;
    _photos = [null, null, null, null];
    _prods = [{ n: '', p: '' }, { n: '', p: '' }];
    renderCurrentStep();
  }

  function renderProgress() {
    const prog = Utils.el('stepProgress');
    if (!prog) return;
    const total = 5;
    let html = '';
    for (let i = 0; i < total; i++) {
      const cls = i < _step ? 'done' : i === _step ? 'active' : '';
      html += `<div class="step-node ${cls}">${i < _step ? '✓' : i + 1}</div>`;
      if (i < total - 1) html += `<div class="step-line ${i < _step ? 'done' : ''}"></div>`;
    }
    prog.innerHTML = html;
    prog.setAttribute('aria-valuenow', _step + 1);
  }

  function renderCurrentStep() {
    renderProgress();
    const container = Utils.el('addshopSteps');
    if (!container) return;
    const renders = [renderStep0, renderStep1, renderStep2, renderStep3, renderStep4];
    container.innerHTML = '';
    renders[_step]?.();
    window.scrollTo(0, 0);
  }

  // STEP 0 — Sector
  function renderStep0() {
    const c = Utils.el('addshopSteps');
    c.innerHTML = `
      <div class="step-card">
        <div class="step-card-header">
          <div class="step-card-title">1. What type of business?</div>
          <div class="step-card-sub">Select the category that best describes your shop</div>
        </div>
        <div class="step-card-body">
          <input class="field-input" id="sectorSearch" placeholder="🔍 Search category…" oninput="DS.addshop._filterSectors(this.value)" style="margin-bottom:12px"/>
          <div class="sector-grid" id="sectorGrid"></div>
        </div>
      </div>
      <div class="step-nav">
        <button class="btn-next" onclick="DS.addshop.next(0)">Next: Business Details →</button>
      </div>`;
    renderSectors('');
  }

  function renderSectors(filter) {
    const grid = Utils.el('sectorGrid');
    if (!grid) return;
    const f = (filter || '').toLowerCase();
    const filtered = f ? SECTORS.filter(s => s.n.toLowerCase().includes(f)) : SECTORS;
    grid.innerHTML = filtered.map(s => `
      <div class="sector-item ${_selSector === s.n ? 'selected' : ''}" onclick="DS.addshop._selectSector('${s.n}','${s.e}')">
        <div class="sector-emoji">${s.e}</div>
        <div class="sector-name">${s.n}</div>
      </div>`).join('');
  }

  function _filterSectors(q) { renderSectors(q); }
  function _selectSector(name, emoji) {
    _selSector = name;
    Utils.toast(`${emoji} ${name} selected`);
    renderSectors(Utils.el('sectorSearch')?.value || '');
  }

  // STEP 1 — Details
  function renderStep1() {
    const c = Utils.el('addshopSteps');
    c.innerHTML = `
      <div class="step-card">
        <div class="step-card-header">
          <div class="step-card-title">2. Business Details</div>
          <div class="step-card-sub">Tell customers what you offer</div>
        </div>
        <div class="step-card-body">
          <div class="field"><label>Business Name <span class="req">*</span></label><input id="f-nm" class="field-input" placeholder="e.g. Sri Murugan Kirana"/></div>
          <div class="field"><label>Owner Name <span class="req">*</span></label><input id="f-ow" class="field-input" placeholder="Your full name"/></div>
          <div class="field"><label>Description <span class="req">*</span></label><textarea id="f-ds" class="field-input" placeholder="What do you offer? What makes you special?"></textarea></div>
          <div class="field-row">
            <div class="field"><label>Est. Year</label><input id="f-yr" class="field-input" type="number" placeholder="2018"/></div>
            <div class="field"><label>Price Range</label><select id="f-pr" class="field-input"><option value="1">₹ Budget</option><option value="2" selected>₹₹ Mid-range</option><option value="3">₹₹₹ Premium</option></select></div>
          </div>
          <div style="margin-top:4px">
            <div style="font-size:.78rem;font-weight:700;color:var(--ink);margin-bottom:4px">Shop Photos <span style="font-size:.7rem;color:var(--ink-3);font-weight:400">(up to 4 images)</span></div>
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px" id="photoGrid"></div>
          </div>
        </div>
      </div>
      <div class="step-nav">
        <button class="btn-back" onclick="DS.addshop.prev()">← Back</button>
        <button class="btn-next" onclick="DS.addshop.next(1)">Next: Location →</button>
      </div>`;
    renderPhotoSlots();
  }

  function renderPhotoSlots() {
    const grid = Utils.el('photoGrid');
    if (!grid) return;
    grid.innerHTML = _photos.map((p, i) => `
      <div onclick="DS.addshop._triggerPhoto(${i})" style="aspect-ratio:1;background:var(--surface-2);border:2px dashed var(--border-2);border-radius:var(--radius-md);display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;overflow:hidden;position:relative;transition:all var(--t-fast)">
        ${p
          ? `<img loading="lazy" decoding="async" src="${p}" style="width:100%;height:100%;object-fit:cover;position:absolute;inset:0"/><button onclick="event.stopPropagation();DS.addshop._removePhoto(${i})" style="position:absolute;top:3px;right:3px;width:20px;height:20px;border-radius:50%;background:rgba(0,0,0,.6);color:white;border:none;font-size:.6rem;cursor:pointer;z-index:2">✕</button>`
          : `<span style="font-size:1.4rem;margin-bottom:3px">📷</span><span style="font-size:.6rem;font-weight:700;color:var(--ink-3)">Add</span>`
        }
        <input type="file" id="pi${i}" accept="image/*" capture="environment" style="display:none" onchange="DS.addshop._handlePhoto(${i},this)"/>
      </div>`).join('');
  }

  function _triggerPhoto(i) { Utils.el(`pi${i}`)?.click(); }
  async function _handlePhoto(i, input) {
    const file = input.files[0];
    if (!file) return;
    if (file.size > 8 * 1024 * 1024) { Utils.toast('⚠️ Image too large — max 8MB'); return; }
    const compressed = await Utils.compressImage(file, 800, 0.82);
    const reader = new FileReader();
    reader.onload = e => { _photos[i] = e.target.result; renderPhotoSlots(); Utils.toast(`✅ Photo ${i + 1} added`); };
    reader.readAsDataURL(compressed);
    input.value = '';
  }
  function _removePhoto(i) { _photos[i] = null; renderPhotoSlots(); }

  // STEP 2 — Location
  function renderStep2() {
    const c = Utils.el('addshopSteps');
    c.innerHTML = `
      <div class="step-card">
        <div class="step-card-header">
          <div class="step-card-title">3. Business Location</div>
          <div class="step-card-sub">Pin your exact location so customers can find you</div>
        </div>
        <div class="step-card-body">
          <button class="gps-btn" onclick="DS.addshop._regGPS()">
            <span id="regGpsIco">📡</span>
            <div class="gps-btn-text"><strong id="regGpsTxt">Use GPS — Find My Location</strong><span>Tap to detect your shop location</span></div>
          </button>
          <div class="field"><label>Street Address <span class="req">*</span></label><input id="f-ad" class="field-input" placeholder="Shop No., Street, Area" oninput="DS.addshop._addrSearch()"/></div>
          <div class="field-row">
            <div class="field"><label>City <span class="req">*</span></label><input id="f-ct" class="field-input" placeholder="e.g. Arakkonam"/></div>
            <div class="field"><label>Pincode <span class="req">*</span></label><input id="f-pc" class="field-input" type="number" placeholder="631101"/></div>
          </div>
          <div id="regMapWrap" style="border-radius:var(--radius-md);overflow:hidden;border:1.5px solid var(--border-2);margin-top:4px">
            <div id="regMapEl" style="height:200px;width:100%;background:var(--surface-2)"></div>
            <div style="background:var(--surface-1);padding:8px 12px;font-size:.72rem;color:var(--ink-3);display:flex;align-items:center;gap:6px">
              <span>📍</span><span id="regMapCoords">Tap GPS or tap map to pin your location</span>
            </div>
          </div>
          ${_pinned ? `<div style="display:flex;align-items:center;gap:7px;background:var(--forest-soft);border:1px solid rgba(10,124,74,.2);border-radius:var(--radius-md);padding:9px 12px;margin-top:10px;font-size:.76rem;color:var(--forest)">✅ Location pinned</div>` : ''}
        </div>
      </div>
      <div class="step-nav">
        <button class="btn-back" onclick="DS.addshop.prev()">← Back</button>
        <button class="btn-next" onclick="DS.addshop.next(2)">Next: Products →</button>
      </div>`;
    setTimeout(() => initRegMap(Store.location?.lat || 13.0772, Store.location?.lng || 79.6712), 300);
  }

  function initRegMap(lat, lng) {
    if (_regMap) { _regMap.setView([lat, lng], 16); if (_regMarker) _regMarker.setLatLng([lat, lng]); return; }
    const el = document.getElementById('regMapEl');
    if (!el || typeof L === 'undefined') return;

    _regMap = L.map('regMapEl', { zoomControl: true, attributionControl: false }).setView([lat, lng], 16);
    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', { maxZoom: 20, subdomains: 'abcd' }).addTo(_regMap);

    _regMarker = L.marker([lat, lng], { draggable: true }).addTo(_regMap);
    _regMarker.on('dragend', e => {
      const p = e.target.getLatLng();
      Store.setLocation(p.lat, p.lng, Store.location?.name || 'Pinned');
      _pinned = true;
      Utils.el('regMapCoords').textContent = `📍 ${p.lat.toFixed(5)}, ${p.lng.toFixed(5)}`;
    });

    _regMap.on('click', e => {
      Store.setLocation(e.latlng.lat, e.latlng.lng, Store.location?.name || 'Pinned');
      _pinned = true;
      if (_regMarker) _regMarker.setLatLng(e.latlng);
      Utils.el('regMapCoords').textContent = `📍 ${e.latlng.lat.toFixed(5)}, ${e.latlng.lng.toFixed(5)}`;
      Utils.toast('📍 Location pinned! Drag the pin to adjust.');
    });

    if (Store.location?.lat) {
      _pinned = true;
      Utils.el('regMapCoords').textContent = `📍 ${lat.toFixed(5)}, ${lng.toFixed(5)}`;
    }
    setTimeout(() => _regMap?.invalidateSize(), 200);
  }

  async function _regGPS() {
    const ico = Utils.el('regGpsIco');
    const txt = Utils.el('regGpsTxt');
    if (!navigator.geolocation) { Utils.toast('GPS not supported'); return; }
    if (ico) ico.textContent = '⏳';
    if (txt) txt.textContent = 'Getting location…';

    navigator.geolocation.getCurrentPosition(async pos => {
      const { latitude: lat, longitude: lng } = pos.coords;
      if (ico) ico.textContent = '✅';
      if (txt) txt.textContent = 'GPS location pinned!';
      _pinned = true;
      const geo = await API.reverseGeocode(lat, lng);
      Store.setLocation(lat, lng, geo.name);
      if (geo.city && !Utils.el('f-ct')?.value) Utils.el('f-ct').value = geo.city;
      if (geo.pincode && !Utils.el('f-pc')?.value) Utils.el('f-pc').value = geo.pincode;
      if (Utils.el('regMapCoords')) Utils.el('regMapCoords').textContent = `📍 ${geo.name}`;
      initRegMap(lat, lng);
      Utils.toast('📡 GPS location pinned!');
    }, () => {
      if (ico) ico.textContent = '📡';
      if (txt) txt.textContent = 'GPS failed — tap the map to pin';
      Utils.toast('GPS failed — tap map to pin your location');
    }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 });
  }

  function _addrSearch() {
    clearTimeout(_addrSearch._t);
    _addrSearch._t = setTimeout(async () => {
      const addr = Utils.el('f-ad')?.value?.trim();
      const city = Utils.el('f-ct')?.value?.trim();
      if (!addr || addr.length < 5) return;
      const results = await API.geocode(`${addr} ${city} Tamil Nadu India`);
      if (results[0]) {
        const lat = parseFloat(results[0].lat), lng = parseFloat(results[0].lon);
        Store.setLocation(lat, lng, Store.location?.name || city || 'Shop');
        _pinned = true;
        initRegMap(lat, lng);
        Utils.el('regMapCoords').textContent = `📍 Found: ${results[0].display_name?.split(',').slice(0, 2).join(',')}`;
      }
    }, 1000);
  }

  // STEP 3 — Products + Contact
  function renderStep3() {
    const c = Utils.el('addshopSteps');
    c.innerHTML = `
      <div class="step-card">
        <div class="step-card-header">
          <div class="step-card-title">4. Products & Contact</div>
          <div class="step-card-sub">Add items and how customers reach you</div>
        </div>
        <div class="step-card-body">
          <div style="font-size:.79rem;font-weight:700;color:var(--ink);margin-bottom:9px">Products / Menu Items</div>
          <div id="prodList"></div>
          <button onclick="DS.addshop._addProd()" style="width:100%;padding:9px;background:var(--surface-2);border:1.5px dashed var(--border-2);border-radius:var(--radius-md);font-size:.77rem;color:var(--ink-3);margin-bottom:14px;cursor:pointer">+ Add Product / Service</button>
          <div style="height:1px;background:var(--border);margin-bottom:13px"></div>
          <div class="field"><label>Phone Number <span class="req">*</span></label><input id="f-ph" class="field-input" type="tel" placeholder="9876543210"/></div>
          <div class="field"><label>WhatsApp for Orders</label><input id="f-wa" class="field-input" type="tel" placeholder="Same as phone or different"/></div>
          <div style="background:var(--surface-2);border:1px solid var(--border);border-radius:var(--radius-md);padding:0 14px">
            <div class="toggle-row">
              <div><div class="toggle-label">Delivery Available</div><div class="toggle-sub">Customers can order for delivery</div></div>
              <label class="toggle"><input type="checkbox" id="tg-d" checked/><div class="toggle-slider"></div></label>
            </div>
          </div>
        </div>
      </div>
      <div class="step-nav">
        <button class="btn-back" onclick="DS.addshop.prev()">← Back</button>
        <button class="btn-next" onclick="DS.addshop.next(3)">Next: Review →</button>
      </div>`;
    _prods.forEach(() => _addProd());
  }

  function _addProd() {
    const list = Utils.el('prodList');
    if (!list) return;
    const idx = list.children.length;
    const row = document.createElement('div');
    row.style.cssText = 'display:grid;grid-template-columns:1fr 88px 28px;gap:6px;align-items:center;margin-bottom:8px';
    row.innerHTML = `
      <input class="field-input prod-n" placeholder="Product / Service name" style="font-size:.83rem;padding:9px"/>
      <input class="field-input prod-p" placeholder="₹ Price" type="number" style="font-size:.83rem;padding:9px"/>
      <button onclick="this.parentElement.remove()" style="background:var(--rose-soft);border:1px solid rgba(192,57,43,.2);border-radius:var(--radius-sm);width:28px;height:36px;color:var(--rose);font-size:.8rem;cursor:pointer">✕</button>`;
    list.appendChild(row);
  }

  function getProds() {
    return [...document.querySelectorAll('.prod-n')].map((el, i) => {
      const name = el.value.trim();
      const priceEl = document.querySelectorAll('.prod-p')[i];
      const price = parseFloat(priceEl?.value || 0);
      return name && price > 0 ? { n: name, p: price } : null;
    }).filter(Boolean);
  }

  // STEP 4 — Review & Submit
  function renderStep4() {
    const c = Utils.el('addshopSteps');
    const sec = SECTORS.find(s => s.n === _selSector) || { e: '🏪' };
    const loc = Store.location;
    c.innerHTML = `
      <div class="step-card">
        <div class="step-card-header">
          <div class="step-card-title">5. Review & Go Live</div>
          <div class="step-card-sub">Check your details before going live</div>
        </div>
        <div class="step-card-body">
          <div style="text-align:center;padding:14px 0">
            <div style="font-size:3rem;margin-bottom:8px">${sec.e}</div>
            <div style="font-family:var(--font-display);font-size:1.2rem;font-weight:700;color:var(--ink);margin-bottom:4px">${Utils.el('f-nm')?.value || '—'}</div>
            <div style="font-size:.73rem;color:var(--ink-3)">📍 ${[Utils.el('f-ad')?.value, Utils.el('f-ct')?.value].filter(Boolean).join(', ')}</div>
          </div>
          <div style="background:var(--surface-2);border-radius:var(--radius-md);overflow:hidden">
            ${[
              ['Category', `${sec.e} ${_selSector}`],
              ['Owner', Utils.el('f-ow')?.value || '—'],
              ['Phone', Utils.el('f-ph')?.value || '—'],
              ['City', Utils.el('f-ct')?.value || '—'],
              ['Location', loc ? '📍 GPS Pinned ✅' : '⚠️ Not pinned'],
              ['Delivery', Utils.el('tg-d')?.checked ? '✅ Yes' : '❌ No'],
            ].map(([l, v]) => `<div style="display:flex;padding:10px 13px;border-bottom:1px solid var(--border);font-size:.8rem"><span style="color:var(--ink-3);width:80px;flex-shrink:0">${l}</span><span style="color:var(--ink);font-weight:600">${v}</span></div>`).join('')}
          </div>
        </div>
      </div>
      <div class="step-nav">
        <button class="btn-back" onclick="DS.addshop.prev()">← Back</button>
        <button class="btn-next" id="submitBtn" onclick="DS.addshop.submit()">🎉 Register & Go Live →</button>
      </div>`;
  }

  async function submit() {
    const btn = Utils.el('submitBtn');
    if (btn) { btn.textContent = '⏳ Going Live…'; btn.disabled = true; }

    const sec = SECTORS.find(s => s.n === _selSector) || { e: '🏪', n: 'Business', g: 'retail' };
    const loc = Store.location;
    const shop = {
      id: Utils.uid('my'),
      name: Utils.sanitize(Utils.el('f-nm')?.value || ''),
      ownerName: Utils.sanitize(Utils.el('f-ow')?.value || ''),
      description: Utils.sanitize(Utils.el('f-ds')?.value || ''),
      sector: (_selSector || '').toLowerCase().replace(/[^a-z]/g, '') || 'retail',
      sectorName: _selSector || 'Business',
      sectorEmoji: sec.e,
      e: sec.e, g: sec.g,
      address: Utils.el('f-ad')?.value || '',
      city: Utils.el('f-ct')?.value || '',
      pincode: Utils.el('f-pc')?.value || '',
      lat: loc?.lat || null,
      lng: loc?.lng || null,
      phone: Utils.el('f-ph')?.value?.replace(/\D/g, '') || '',
      whatsapp: Utils.el('f-wa')?.value?.replace(/\D/g, '') || Utils.el('f-ph')?.value?.replace(/\D/g, '') || '',
      priceLevel: Utils.el('f-pr')?.value || '2',
      price: parseInt(Utils.el('f-pr')?.value || '2'),
      delivery: !!Utils.el('tg-d')?.checked,
      hours: { Monday: { open: '09:00', close: '21:00' } },
      products: getProds().map(p => ({ name: p.n, price: p.p, emoji: '🍽️', category: 'Menu' })),
      prods: getProds(),
      photos: _photos.filter(Boolean),
      ownerUID: Store.user?.uid || '',
      registeredAt: Date.now(),
      bizId: 'DS-' + Date.now().toString().slice(-6),
      rating: 0, rc: 0, views: 1, verified: false, reg: Date.now(),
      wa: Utils.el('f-wa')?.value?.replace(/\D/g, '') || Utils.el('f-ph')?.value?.replace(/\D/g, '') || '',
      oh: '09:00', oc: '21:00',
    };

    // Save locally first — always works
    Store.addLocalShop(shop);
    if (Store.user?.phone) {
      // Tag with owner phone for identity
    }

    // Try server (don't block on failure)
    let savedToServer = false;
    try {
      const result = await API.createShop(shop);
      if (result && (result.ok || result.id)) {
        shop.id = result.id || shop.id;
        savedToServer = true;
      }
    } catch {}

    // WhatsApp notification to Deckscrab
    const notify = encodeURIComponent(`🏪 New shop on Deckscrab!\n\n${shop.name}\n${shop.sectorName}\n📍 ${shop.city}\n📞 ${shop.phone}`);
    setTimeout(() => window.open(`https://wa.me/919384707706?text=${notify}`, '_blank'), 1000);

    if (btn) { btn.textContent = '🎉 Register & Go Live →'; btn.disabled = false; }
    renderSuccess(shop, savedToServer);
  }

  function renderSuccess(shop, savedToServer) {
    const c = Utils.el('addshopSteps');
    const slug = API.slugify(shop.name);
    const webUrl = `https://waseem-2007.github.io/deckscrab/?shop=${slug}`;
    c.innerHTML = `
      <div style="text-align:center;padding:40px 20px;animation:pageIn .3s var(--ease-out)">
        <div class="pop-in" style="font-size:4rem;margin-bottom:14px">🎉</div>
        <div style="font-family:var(--font-display);font-size:1.6rem;font-weight:800;color:var(--forest);margin-bottom:10px">You're Live!</div>
        <div style="font-size:.84rem;color:var(--ink-3);line-height:1.7;margin-bottom:24px;max-width:300px;margin-left:auto;margin-right:auto">Your business is now visible to customers on Deckscrab.</div>
        <div style="background:var(--surface-1);border:1.5px solid rgba(10,124,74,.2);border-radius:var(--radius-lg);padding:16px;text-align:left;margin-bottom:16px">
          ${[['Shop', shop.name], ['Category', shop.sectorName], ['City', shop.city], ['Server', savedToServer ? '✅ Live everywhere!' : '📱 Saved locally — sync from Profile']].map(([l, v]) => `<div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--border);font-size:.8rem"><span style="color:var(--ink-3);width:76px;flex-shrink:0">${l}</span><span style="color:var(--ink);font-weight:600">${v}</span></div>`).join('')}
        </div>
        <div style="display:flex;gap:8px;margin-bottom:8px">
          <a href="${webUrl}" target="_blank" style="flex:1;padding:12px;background:var(--flame);color:white;border-radius:var(--radius-md);font-size:.84rem;font-weight:700;text-decoration:none;display:flex;align-items:center;justify-content:center">🌐 View Shop</a>
          <button onclick="navigator.clipboard?.writeText('${webUrl}').then(()=>Utils.toast('✅ Link copied!'))" style="flex:1;padding:12px;background:var(--surface-2);border:1.5px solid var(--border-2);border-radius:var(--radius-md);font-size:.83rem;font-weight:700;color:var(--ink)">📋 Copy Link</button>
        </div>
        <button onclick="window.open('https://wa.me/?text='+encodeURIComponent('Order from ${shop.name}:\\n${webUrl}'),'_blank')" style="width:100%;padding:12px;background:#25D366;color:white;border:none;border-radius:var(--radius-md);font-size:.84rem;font-weight:700;margin-bottom:10px">💬 Share on WhatsApp</button>
        <button onclick="DS.nav.go('profile')" style="width:100%;padding:12px;background:none;border:1.5px solid var(--border-2);border-radius:var(--radius-md);font-size:.84rem;font-weight:600;color:var(--ink-2)">📋 View My Shops →</button>
      </div>`;
    renderProgress();
  }

  // Navigation
  function next(from) {
    if (from === 0 && !_selSector) { Utils.toast('⚠️ Please select a business category'); return; }
    if (from === 1) {
      if (!Utils.el('f-nm')?.value?.trim()) { Utils.toast('⚠️ Enter your business name'); return; }
      if (!Utils.el('f-ow')?.value?.trim()) { Utils.toast('⚠️ Enter your name'); return; }
    }
    if (from === 2 && !_pinned) { Utils.toast('📍 Pin your location on the map or use GPS'); return; }
    if (from === 3 && !Utils.el('f-ph')?.value?.trim()) { Utils.toast('⚠️ Enter your phone number'); return; }
    if (from === 3) renderStep4();
    _step = from + 1;
    renderCurrentStep();
  }

  function prev() {
    if (_step > 0) { _step--; renderCurrentStep(); }
  }

  return {
    init, next, prev, submit,
    _selectSector, _filterSectors, renderSectors,
    _triggerPhoto, _handlePhoto, _removePhoto,
    _addProd, _regGPS, _addrSearch,
  };
})();
