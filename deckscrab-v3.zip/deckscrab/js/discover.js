/**
 * discover.js — Map + bottom sheet discover page
 */
const DiscoverModule = (() => {
  let _map = null;
  let _markers = [];
  let _userMarker = null;
  let _radarLines = [];
  let _shown = [];
  let _sortMode = 'newest';
  let _openOnly = false;
  let _radar = false;
  let _catFilter = '';
  let _sheetOpen = false;

  // ── Map init ──
  function initMap() {
    if (_map) { setTimeout(() => _map.invalidateSize({ pan: false }), 100); return; }

    const container = Utils.el('discoverMap');
    if (!container) return;

    const loc = Store.location;
    const center = loc ? [loc.lat, loc.lng] : [11.1271, 78.6569]; // Tamil Nadu center

    _map = L.map('discoverMap', {
      zoomControl: false,
      scrollWheelZoom: true,
      tap: true,
      tapTolerance: 15,
      attributionControl: false,
      preferCanvas: true,
    }).setView(center, loc ? 14 : 8);

    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
      maxZoom: 19,
      subdomains: 'abcd',
    }).addTo(_map);

    L.control.zoom({ position: 'bottomleft' }).addTo(_map);

    // Inject popup styles
    if (!document.getElementById('_discPopupStyle')) {
      const s = document.createElement('style');
      s.id = '_discPopupStyle';
      s.textContent = `
        .ds-popup .leaflet-popup-content-wrapper { min-width:190px; }
        .leaflet-control-zoom { margin-left:10px!important; margin-bottom:100px!important; }
      `;
      document.head.appendChild(s);
    }

    [50, 200, 500, 1000].forEach(t => setTimeout(() => _map && _map.invalidateSize({ pan: false }), t));
    window.addEventListener('resize', () => setTimeout(() => _map && _map.invalidateSize({ pan: false }), 200), { passive: true });
  }

  function buildCatBar() {
    const bar = Utils.el('discCatBar');
    if (!bar) return;
    const cats = [
      { id: '',           label: '🌟 All' },
      { id: 'food',       label: '🍛 Food' },
      { id: 'health',     label: '🏥 Health' },
      { id: 'service',    label: '🔧 Services' },
      { id: 'retail',     label: '🛒 Retail' },
      { id: 'beauty',     label: '💇 Beauty' },
      { id: 'education',  label: '🏫 School' },
      { id: 'finance',    label: '🏦 Finance' },
      { id: 'religious',  label: '🛕 Temple' },
    ];
    bar.innerHTML = cats.map(c =>
      `<button class="disc-cat-btn ${_catFilter === c.id ? 'active' : ''}" onclick="DS.discover.setCat('${c.id}',this)">${c.label}</button>`
    ).join('');
  }

  function setCat(cat, el) {
    _catFilter = cat;
    document.querySelectorAll('.disc-cat-btn').forEach(b => b.classList.remove('active'));
    if (el) el.classList.add('active');
    render();
  }

  function toggleOpenNow() {
    _openOnly = !_openOnly;
    const btn = Utils.el('openNowFab');
    if (btn) btn.setAttribute('aria-pressed', _openOnly);
    render();
    Utils.toast(_openOnly ? '🟢 Open now only' : 'Showing all shops');
  }

  function toggleRadar() {
    _radar = !_radar;
    const btn = Utils.el('radarFab');
    if (btn) btn.setAttribute('aria-pressed', _radar);
    if (!_radar) {
      _radarLines.forEach(l => { try { _map.removeLayer(l); } catch {} });
      _radarLines = [];
      Utils.toast('📡 Radar off');
    } else {
      if (!Store.location) { Utils.toast('📍 Set your location first'); _radar = false; if (btn) btn.setAttribute('aria-pressed', 'false'); return; }
      _shown.filter(s => s.lat && s.lng).forEach(drawRadarLine);
      Utils.toast(`📡 Radar — ${_shown.length} shops`);
    }
  }

  function drawRadarLine(s) {
    if (!_map || !Store.location || !s.lat || !s.lng) return;
    const loc = Store.location;
    const color = Utils.sectorColor(s);
    const dist = Utils.km(loc.lat, loc.lng, +s.lat, +s.lng);
    const line = L.polyline([[loc.lat, loc.lng], [+s.lat, +s.lng]], { color, weight: 1.5, dashArray: '5 5', opacity: 0.5 }).addTo(_map);
    const mid = [(loc.lat + (+s.lat)) / 2, (loc.lng + (+s.lng)) / 2];
    const lbl = L.marker(mid, {
      icon: L.divIcon({
        className: '',
        html: `<div style="background:white;border:1.5px solid ${color};border-radius:20px;padding:2px 7px;font-size:10px;font-weight:800;color:${color};white-space:nowrap;box-shadow:var(--shadow-sm)">${Utils.fmtDist(dist)}</div>`,
        iconAnchor: [28, 10],
      }),
      interactive: false,
    }).addTo(_map);
    _radarLines.push(line, lbl);
  }

  function sort(mode, el) {
    _sortMode = mode;
    document.querySelectorAll('.sort-btn').forEach(b => b.classList.remove('active'));
    if (el) el.classList.add('active');
    render();
  }

  function search(q) {
    Utils.el('discClearBtn').hidden = !q;
    // Debounced render
    clearTimeout(search._t);
    search._t = setTimeout(() => render(q), 250);
  }

  function clearSearch() {
    const inp = Utils.el('discSearchInp');
    if (inp) inp.value = '';
    Utils.el('discClearBtn').hidden = true;
    render('');
  }

  function getFiltered(q = '') {
    let shops = Store.allShops();
    if (q) {
      const lq = q.toLowerCase();
      shops = shops.filter(s =>
        (s.name || '').toLowerCase().includes(lq) ||
        (s.sectorName || '').toLowerCase().includes(lq) ||
        (s.desc || '').toLowerCase().includes(lq) ||
        (s.city || '').toLowerCase().includes(lq)
      );
    }
    if (_catFilter) {
      shops = shops.filter(s => {
        const sec = (s.sector || s.sectorName || s.g || '').toLowerCase();
        return s.g === _catFilter || sec.includes(_catFilter);
      });
    }
    if (_openOnly) shops = shops.filter(s => Utils.isOpen(s));

    const loc = Store.location;
    if (_sortMode === 'newest') shops.sort((a, b) => (b.reg || 0) - (a.reg || 0));
    else if (_sortMode === 'rating') shops.sort((a, b) => (b.rating || 0) - (a.rating || 0));
    else if (_sortMode === 'dist' && loc) {
      shops.sort((a, b) => {
        const da = (a.lat && a.lng) ? Utils.km(loc.lat, loc.lng, +a.lat, +a.lng) : 9999;
        const db = (b.lat && b.lng) ? Utils.km(loc.lat, loc.lng, +b.lat, +b.lng) : 9999;
        return da - db;
      });
    }
    return shops;
  }

  function renderCards() {
    const el = Utils.el('discCards');
    if (!el) return;
    const loc = Store.location;

    if (!_shown.length) {
      el.innerHTML = `
        <div class="empty-state" style="padding:28px 16px">
          <div class="empty-state-icon">🗺️</div>
          <div class="empty-state-title">No shops on map</div>
          <div class="empty-state-sub">Try a different category or <button onclick="DS.nav.go('addshop')" style="color:var(--flame);background:none;border:none;font-size:inherit;font-weight:700;cursor:pointer">add yours</button></div>
        </div>`;
      return;
    }

    el.innerHTML = _shown.map((s, i) => {
      const open = Utils.isOpen(s);
      const dist = loc && s.lat && s.lng ? Utils.km(loc.lat, loc.lng, +s.lat, +s.lng) : null;
      return `
        <div class="disc-card" id="dc-${s.id}" onclick="DS.detail.open('${s.id}')" role="listitem" style="animation-delay:${Math.min(i * 20, 200)}ms">
          <div class="disc-card-thumb">${s.e || s.sectorEmoji || '🏪'}</div>
          <div class="disc-card-info">
            <div class="disc-card-top">
              <span class="disc-card-name">${s.name}</span>
              <span class="disc-card-status ${open ? 'open' : 'closed'}">${open ? '● Open' : '● Closed'}</span>
            </div>
            <div class="disc-card-meta">${s.sectorName || s.sector || ''}${s.city ? ' · ' + s.city : ''}</div>
            <div class="disc-card-foot">
              ${dist !== null ? `<span class="disc-card-dist">📍 ${Utils.fmtDist(dist)}</span>` : ''}
              ${s.rating ? `<span class="disc-card-rating">★ ${s.rating}</span>` : ''}
              <span class="disc-card-price">${Utils.priceLevel(s)}</span>
            </div>
          </div>
        </div>`;
    }).join('');
  }

  function renderMarkers() {
    if (!_map) return;
    _markers.forEach(m => { try { _map.removeLayer(m); } catch {} });
    _markers = [];

    // User location
    if (Store.location) {
      const { lat, lng } = Store.location;
      if (_userMarker) { try { _map.removeLayer(_userMarker); } catch {} }
      _userMarker = L.circleMarker([lat, lng], {
        radius: 10,
        fillColor: '#FF4D00',
        fillOpacity: 1,
        color: 'white',
        weight: 3,
        zIndexOffset: 1000,
      }).addTo(_map).bindPopup('<b style="font-family:DM Sans,sans-serif">📍 You</b>');
      _markers.push(_userMarker);
    }

    const loc = Store.location;
    _shown.filter(s => s.lat && s.lng && !isNaN(+s.lat)).forEach(s => {
      const open  = Utils.isOpen(s);
      const color = open ? Utils.sectorColor(s) : '#9CA3AF';
      const emoji = s.e || s.sectorEmoji || '🏪';
      const dist  = loc ? Utils.km(loc.lat, loc.lng, +s.lat, +s.lng) : null;

      const icon = L.divIcon({
        className: '',
        html: `<div style="background:${color};width:40px;height:40px;border-radius:50%;border:3px solid white;box-shadow:0 3px 10px rgba(0,0,0,.28);display:flex;align-items:center;justify-content:center;font-size:17px">${emoji}</div>`,
        iconSize: [40, 40],
        iconAnchor: [20, 20],
        popupAnchor: [0, -24],
      });

      const m = L.marker([+s.lat, +s.lng], { icon, zIndexOffset: open ? 300 : 100 }).addTo(_map);

      // Build popup as DOM (no quote-escaping issues)
      const popup = document.createElement('div');
      popup.style.fontFamily = 'DM Sans, sans-serif';
      popup.innerHTML = `
        <div style="background:${color};padding:9px 11px;margin:-13px -20px 8px;border-radius:7px 7px 0 0">
          <div style="font-weight:800;color:white;font-size:13px">${s.name}</div>
          <div style="color:rgba(255,255,255,.75);font-size:10px">${s.sectorName || ''}${s.city ? ' · ' + s.city : ''}</div>
        </div>
        <div style="font-size:11px;margin-bottom:8px">
          ${open ? '<span style="color:#0A7C4A;font-weight:700">● Open</span>' : '<span style="color:#C0392B;font-weight:700">● Closed</span>'}
          ${dist !== null ? `<span style="color:#666;margin-left:6px">· ${Utils.fmtDist(dist)}</span>` : ''}
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:5px"></div>`;

      const btnView = document.createElement('button');
      btnView.textContent = 'View Shop';
      btnView.style.cssText = `background:${color};color:white;border:none;border-radius:7px;padding:7px;font-size:11px;font-weight:700;cursor:pointer;width:100%;font-family:DM Sans,sans-serif`;
      btnView.onclick = () => DS.detail.open(s.id);

      const btnDir = document.createElement('button');
      btnDir.textContent = '🧭 Navigate';
      btnDir.style.cssText = `background:#0A7C4A;color:white;border:none;border-radius:7px;padding:7px;font-size:11px;font-weight:700;cursor:pointer;width:100%;font-family:DM Sans,sans-serif`;
      btnDir.onclick = () => DS.detail.navigate(s);

      popup.querySelector('div:last-child').appendChild(btnView);
      popup.querySelector('div:last-child').appendChild(btnDir);

      m.bindPopup(popup, { maxWidth: 220, className: 'ds-popup' });
      m.on('click', () => {
        document.querySelectorAll('.disc-card').forEach(c => c.classList.remove('highlighted'));
        const card = document.getElementById('dc-' + s.id);
        if (card) {
          card.classList.add('highlighted');
          card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
        if (!_sheetOpen) expandSheet();
      });
      _markers.push(m);
    });

    // Fit map
    const hasPts = _shown.filter(s => s.lat && s.lng && !isNaN(+s.lat));
    const allPts = [...(Store.location ? [[Store.location.lat, Store.location.lng]] : []), ...hasPts.map(s => [+s.lat, +s.lng])];
    if (allPts.length > 1) {
      try { _map.fitBounds(L.latLngBounds(allPts), { padding: [80, 60], maxZoom: 16, animate: true }); } catch {}
    } else if (allPts.length === 1) {
      _map.setView(allPts[0], 15, { animate: true });
    }

    // Radar
    if (_radar) {
      _radarLines.forEach(l => { try { _map.removeLayer(l); } catch {} });
      _radarLines = [];
      _shown.filter(s => s.lat && s.lng).forEach(drawRadarLine);
    }
  }

  function fitAll() {
    if (!_map) return;
    const pts = _shown.filter(s => s.lat && s.lng && !isNaN(+s.lat));
    const all = [...(Store.location ? [[Store.location.lat, Store.location.lng]] : []), ...pts.map(s => [+s.lat, +s.lng])];
    if (all.length > 1) { try { _map.fitBounds(L.latLngBounds(all), { padding: [80, 80], maxZoom: 15, animate: true }); } catch {} }
    else if (Store.location) { _map.setView([Store.location.lat, Store.location.lng], 14, { animate: true }); }
    Utils.toast(`🗺️ ${_shown.length} shops`);
  }

  function expandSheet() {
    _sheetOpen = true;
    const sheet = Utils.el('discSheet');
    if (sheet) sheet.classList.add('expanded');
  }

  function collapseSheet() {
    _sheetOpen = false;
    const sheet = Utils.el('discSheet');
    if (sheet) sheet.classList.remove('expanded');
  }

  function setupSheetSwipe() {
    const handle = Utils.el('discHandle');
    const sheet  = Utils.el('discSheet');
    if (!handle || !sheet) return;

    let startY = 0, startT = 0;
    handle.addEventListener('touchstart', e => { startY = e.touches[0].clientY; startT = Date.now(); }, { passive: true });
    handle.addEventListener('touchend', e => {
      const dy = e.changedTouches[0].clientY - startY;
      const dt = Date.now() - startT;
      if (dt < 300) {
        if (dy < -30) expandSheet();
        else if (dy > 30) collapseSheet();
        else _sheetOpen ? collapseSheet() : expandSheet();
      }
    }, { passive: true });

    handle.addEventListener('click', () => _sheetOpen ? collapseSheet() : expandSheet());
  }

  function render(q = Utils.el('discSearchInp')?.value || '') {
    if (!_map) return;
    _shown = getFiltered(q);
    Utils.setText('discCount', `${_shown.length} shop${_shown.length !== 1 ? 's' : ''}`);
    renderCards();
    renderMarkers();
    setTimeout(() => _map && _map.invalidateSize({ pan: false }), 200);
  }

  async function init() {
    initMap();
    buildCatBar();
    setupSheetSwipe();
    render();

    // Auto-detect location
    if (!Store.location && navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async pos => {
          const geo = await API.reverseGeocode(pos.coords.latitude, pos.coords.longitude);
          DS.location.pick(geo.name, pos.coords.latitude, pos.coords.longitude);
        },
        () => {},
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
      );
    }
  }

  return {
    init, render, fitAll,
    setCat, sort, search, clearSearch,
    toggleOpenNow, toggleRadar,
    get _map() { return _map; },
  };
})();
