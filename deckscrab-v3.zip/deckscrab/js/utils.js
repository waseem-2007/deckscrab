/**
 * utils.js — Shared utility functions
 */
const Utils = (() => {

  // ── Distance ──
  function km(lat1, lng1, lat2, lng2) {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) ** 2 +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLng / 2) ** 2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }

  function fmtDist(d) {
    return d < 1 ? Math.round(d * 1000) + 'm' : d.toFixed(1) + ' km';
  }

  // ── Open/Closed ──
  function isOpen(shop) {
    try {
      const now = new Date();
      const cur = now.getHours() * 60 + now.getMinutes();
      const [oh, om] = (shop.oh || '00:00').split(':').map(Number);
      const [ch, cm] = (shop.oc || '23:59').split(':').map(Number);
      if (oh === 0 && ch === 23) return true;
      return cur >= (oh * 60 + om) && cur <= (ch * 60 + cm);
    } catch { return false; }
  }

  // ── Stars HTML ──
  function starsHtml(rating, size = '0.8rem') {
    return [1, 2, 3, 4, 5].map(i =>
      `<span style="color:${i <= Math.round(rating) ? '#D97706' : 'var(--ink-5)'};font-size:${size}">★</span>`
    ).join('');
  }

  // ── Price level ──
  function priceLevel(shop) {
    return '₹'.repeat(Math.min(Math.max(parseInt(shop.price || 2), 1), 3));
  }

  // ── Sector color ──
  const SECTOR_COLORS = {
    food: '#E8521A', restaurant: '#E8521A', cafe: '#92400E',
    grocery: '#1D4ED8', retail: '#1D4ED8',
    health: '#0891B2', hospital: '#0E7490', doctor: '#0D9488', pharmacy: '#059669',
    beauty: '#DB2777', salon: '#BE185D', gym: '#7C3AED',
    service: '#D97706', mechanic: '#B45309', welder: '#C2410C',
    education: '#4F46E5', finance: '#1E3A5F',
    religious: '#B45309', temple: '#92400E',
  };
  function sectorColor(shop) {
    const sec = (shop.sector || shop.sectorName || shop.g || '').toLowerCase();
    for (const [k, v] of Object.entries(SECTOR_COLORS)) {
      if (sec.includes(k)) return v;
    }
    return '#4B5563';
  }

  // ── Toast ──
  let _toastTimer;
  function toast(msg, duration = 2800) {
    const el = document.getElementById('toast');
    if (!el) return;
    el.textContent = msg;
    el.classList.add('visible');
    clearTimeout(_toastTimer);
    _toastTimer = setTimeout(() => el.classList.remove('visible'), duration);
  }

  // ── Debounce ──
  function debounce(fn, ms) {
    let t;
    return (...args) => {
      clearTimeout(t);
      t = setTimeout(() => fn(...args), ms);
    };
  }

  // ── DOM helpers ──
  function el(id) { return document.getElementById(id); }
  function setText(id, val) { const e = el(id); if (e) e.textContent = val; }
  function setHTML(id, val) { const e = el(id); if (e) e.innerHTML = val; }

  // ── Share shop ──
  function shareShop(shop) {
    const slug = API.slugify(shop.name);
    const url = `https://waseem-2007.github.io/deckscrab/?shop=${slug}`;
    const text = `🏪 ${shop.name}\n📍 ${shop.addr || ''}, ${shop.city || ''}\n\nOrder online: ${url}`;
    if (navigator.share) {
      navigator.share({ title: shop.name, text, url }).catch(() => {});
    } else {
      window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
    }
  }

  // ── WhatsApp link ──
  function waLink(phone, msg) {
    const clean = (phone || '').replace(/\D/g, '').slice(-10);
    return `https://wa.me/91${clean}?text=${encodeURIComponent(msg)}`;
  }

  // ── Generate unique ID ──
  function uid(prefix = 'ds') {
    return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  }

  // ── Sanitize string ──
  function sanitize(str, maxLen = 200) {
    return (str || '').replace(/[<>"']/g, '').trim().slice(0, maxLen);
  }

  // ── Compress image in browser ──
  function compressImage(file, maxPx = 800, quality = 0.82) {
    return new Promise(resolve => {
      const img = new Image();
      const url = URL.createObjectURL(file);
      img.onload = () => {
        URL.revokeObjectURL(url);
        let { width: w, height: h } = img;
        if (w > maxPx || h > maxPx) {
          if (w > h) { h = Math.round(h * maxPx / w); w = maxPx; }
          else { w = Math.round(w * maxPx / h); h = maxPx; }
        }
        const c = document.createElement('canvas');
        c.width = w; c.height = h;
        c.getContext('2d').drawImage(img, 0, 0, w, h);
        c.toBlob(blob => resolve(blob || file), 'image/jpeg', quality);
      };
      img.onerror = () => resolve(file);
      img.src = url;
    });
  }

  return {
    km, fmtDist, isOpen, starsHtml, priceLevel, sectorColor,
    toast, debounce,
    el, setText, setHTML,
    shareShop, waLink, uid, sanitize, compressImage,
  };
})();
