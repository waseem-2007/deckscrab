/**
 * home.js — Home page rendering and interactions
 */
const HomeModule = (() => {
  const CAT_GROUPS = {
    food:       ['food','restaurant','tiffin','biryani','fastfood','cafe','juice','sweets','icecream','catering','cakeshop','bakery','mess','hotel'],
    grocery:    ['grocery','retail','supermarket','fruits','dairy','kirana','provision'],
    health:     ['health','doctor','dentist','hospital','lab','physio','pharmacy','clinic','medical','nursing'],
    service:    ['service','welder','welding','plumber','electrician','mechanic','carpenter','painter','tailor','acrepair','mobilerepair','cleaning','taxi','courier'],
    beauty:     ['beauty','salon','spa','gym','yoga','cosmetics','parlour'],
    education:  ['education','school','tuition','computer','driving','music','library','coaching'],
    finance:    ['finance','bank','insurance','ca','lawyer','realestate','travel'],
    religious:  ['religious','temple','church','mosque','pooja'],
    retail:     ['retail','clothes','electronics','hardware','jewellery','furniture','shoes','opticals'],
  };

  const CATS = [
    { id: '',          emoji: '🌟', label: 'All' },
    { id: 'food',      emoji: '🍛', label: 'Food' },
    { id: 'grocery',   emoji: '🛒', label: 'Grocery' },
    { id: 'health',    emoji: '🏥', label: 'Health' },
    { id: 'service',   emoji: '🔧', label: 'Service' },
    { id: 'beauty',    emoji: '💇', label: 'Beauty' },
    { id: 'education', emoji: '🏫', label: 'School' },
    { id: 'finance',   emoji: '🏦', label: 'Finance' },
    { id: 'religious', emoji: '🛕', label: 'Temple' },
    { id: 'retail',    emoji: '🛍️', label: 'Shops' },
  ];

  function shopMatchesCat(shop, cat) {
    if (!cat) return true;
    const sec = (shop.sector || shop.sectorName || shop.g || '').toLowerCase();
    if (shop.g === cat) return true;
    return (CAT_GROUPS[cat] || []).some(k => sec.includes(k) || shop.g === k);
  }

  function buildCatBar() {
    const bar = Utils.el('catBar');
    if (!bar) return;
    const cur = Store.state.catFilter;
    bar.innerHTML = CATS.map(c => `
      <button
        class="cat-btn ${cur === c.id ? 'active' : ''}"
        onclick="DS.home.setCat('${c.id}',this)"
        role="tab"
        aria-selected="${cur === c.id}"
      >
        <div class="cat-icon-wrap">${c.emoji}</div>
        <span class="cat-label">${c.label}</span>
      </button>`
    ).join('');
  }

  function setCat(cat, el) {
    Store.setFilter('catFilter', cat);
    document.querySelectorAll('.cat-btn').forEach(b => {
      b.classList.remove('active');
      b.setAttribute('aria-selected', 'false');
    });
    if (el) { el.classList.add('active'); el.setAttribute('aria-selected', 'true'); }
    render();
  }

  function toggleNear() {
    const newVal = !Store.state.nearMe;
    Store.setFilter('nearMe', newVal);
    const btn = Utils.el('filterNear');
    if (btn) btn.setAttribute('aria-pressed', newVal);
    if (newVal && !Store.location) { DS.location.openModal(); Store.setFilter('nearMe', false); if (btn) btn.setAttribute('aria-pressed', 'false'); return; }
    if (newVal) Utils.toast('📍 Showing closest shops first');
    render();
  }

  function toggleOpen() {
    const newVal = !Store.state.openOnly;
    Store.setFilter('openOnly', newVal);
    const btn = Utils.el('filterOpen');
    if (btn) { btn.setAttribute('aria-pressed', newVal); btn.classList.toggle('open-btn', newVal); }
    if (newVal) Utils.toast('🟢 Open shops only');
    render();
  }

  const onSearch = Utils.debounce(q => { Store.setFilter('searchQuery', q); render(); }, 280);

  function quickSearch(term) {
    const inp = Utils.el('homeSearchInp');
    if (inp) inp.value = term;
    Store.setFilter('searchQuery', term.toLowerCase());
    render();
  }

  function runSearch() {
    const q = Utils.el('homeSearchInp')?.value || '';
    Store.setFilter('searchQuery', q.toLowerCase());
    render();
  }

  function getFiltered() {
    let shops = Store.allShops();
    const { searchQuery, catFilter, openOnly, nearMe } = Store.state;
    const loc = Store.location;

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      shops = shops.filter(s =>
        (s.name || '').toLowerCase().includes(q) ||
        (s.sectorName || s.sector || '').toLowerCase().includes(q) ||
        (s.desc || '').toLowerCase().includes(q) ||
        (s.city || '').toLowerCase().includes(q) ||
        (s.addr || '').toLowerCase().includes(q)
      );
    }

    if (catFilter) shops = shops.filter(s => shopMatchesCat(s, catFilter));
    if (openOnly)  shops = shops.filter(s => Utils.isOpen(s));
    if (nearMe && loc) {
      shops.sort((a, b) => {
        const da = (a.lat && a.lng) ? Utils.km(loc.lat, loc.lng, +a.lat, +a.lng) : 9999;
        const db = (b.lat && b.lng) ? Utils.km(loc.lat, loc.lng, +b.lat, +b.lng) : 9999;
        return da - db;
      });
    }

    return shops;
  }

  function renderFeatured() {
    const wrap = Utils.el('featuredScroll');
    if (!wrap) return;
    // Only show when no filters active
    const { searchQuery, catFilter, openOnly, nearMe } = Store.state;
    const featWrap = wrap.closest ? wrap.parentElement?.previousElementSibling : null;

    if (searchQuery || catFilter || openOnly || nearMe) {
      wrap.style.display = 'none';
      const hdr = wrap.previousElementSibling;
      if (hdr) hdr.style.display = 'none';
      return;
    }
    wrap.style.display = '';
    const prevEl = wrap.previousElementSibling;
    if (prevEl) prevEl.style.display = '';

    const loc = Store.location;
    const featured = Store.allShops()
      .filter(s => Utils.isOpen(s))
      .sort((a, b) => (b.rating || 0) - (a.rating || 0))
      .slice(0, 6);

    const GRADS = [
      'linear-gradient(150deg,#2d0e00,#7c2d00)',
      'linear-gradient(150deg,#001228,#0b2e60)',
      'linear-gradient(150deg,#00200a,#005928)',
      'linear-gradient(150deg,#1a0015,#4a0035)',
      'linear-gradient(150deg,#0a0010,#1a0040)',
      'linear-gradient(150deg,#1a1000,#3d2800)',
    ];

    wrap.innerHTML = featured.length
      ? featured.map((s, i) => {
          const open = Utils.isOpen(s);
          const dist = loc && s.lat && s.lng
            ? Utils.fmtDist(Utils.km(loc.lat, loc.lng, +s.lat, +s.lng))
            : null;
          return `
          <div class="featured-card" style="background:${GRADS[i % GRADS.length]}" onclick="DS.detail.open('${s.id}')" role="listitem">
            <div class="feat-bg">${s.e || s.sectorEmoji || '🏪'}</div>
            <div class="feat-overlay"></div>
            <div class="feat-body">
              <div class="feat-category">${s.sectorName || s.sector || ''} · ${s.city || ''}</div>
              <div class="feat-name">${s.name}</div>
              <div class="feat-meta">
                <span class="${open ? 'feat-open' : 'feat-closed'}">${open ? 'Open' : 'Closed'}</span>
                ${dist ? `<span class="feat-dist">📍 ${dist}</span>` : ''}
                ${s.rating ? `<span class="feat-stars">★ ${s.rating}</span>` : ''}
              </div>
            </div>
          </div>`;
        }).join('')
      : '<div style="padding:20px;color:var(--ink-3);font-size:.82rem">Loading nearby businesses…</div>';
  }

  function renderList(shops) {
    const list = Utils.el('homeShopList');
    if (!list) return;
    const count = Utils.el('homeResultCount');
    if (count) count.textContent = shops.length ? `${shops.length} business${shops.length !== 1 ? 'es' : ''}` : '';

    if (!shops.length) {
      const { searchQuery, catFilter } = Store.state;
      list.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">🏪</div>
          <div class="empty-state-title">${searchQuery ? `No results for "${searchQuery}"` : 'No businesses yet'}</div>
          <div class="empty-state-sub">${searchQuery || catFilter ? 'Try a different search.' : 'Be the first to register!'}</div>
          <button class="btn-primary" style="margin-top:16px" onclick="DS.nav.go('addshop')">+ Register Your Business</button>
        </div>`;
      return;
    }

    const loc = Store.location;
    list.innerHTML = shops.map(s => {
      const open  = Utils.isOpen(s);
      const dist  = loc && s.lat && s.lng ? Utils.km(loc.lat, loc.lng, +s.lat, +s.lng) : null;
      const color = Utils.sectorColor(s);
      return `
        <div class="shop-card" onclick="DS.detail.open('${s.id}')" role="listitem" style="--accent:${color}">
          <div class="shop-card-accent" style="position:absolute;left:0;top:0;bottom:0;width:4px;border-radius:var(--radius-sm) 0 0 var(--radius-sm);background:${color}"></div>
          <div class="shop-card-inner">
            <div class="shop-emoji-wrap" style="background:${color}18;border:1.5px solid ${color}33">${s.e || s.sectorEmoji || '🏪'}</div>
            <div class="shop-body">
              <div class="shop-name">${s.name}</div>
              <div class="shop-sector">${s.sectorName || s.sector || ''}</div>
              ${s.addr || s.city ? `<div class="shop-addr">📍 ${[s.addr, s.city].filter(Boolean).join(', ')}</div>` : ''}
              <div class="shop-foot">
                <span class="shop-status ${open ? 'open' : 'closed'}">${open ? '● Open' : '● Closed'}</span>
                ${dist !== null ? `<span class="shop-dist">📍 ${Utils.fmtDist(dist)}</span>` : ''}
                ${s.rating ? `<span class="shop-rating">★ ${s.rating}</span>` : ''}
                <span class="shop-price">${Utils.priceLevel(s)}</span>
              </div>
            </div>
          </div>
        </div>`;
    }).join('');
  }

  function showSkeletons(n = 4) {
    const list = Utils.el('homeShopList');
    if (!list) return;
    list.innerHTML = Array(n).fill(0).map(() =>
      `<div class="skel" style="height:88px;margin-bottom:10px;border-radius:var(--radius-lg)"></div>`
    ).join('');
  }

  async function render() {
    buildCatBar();
    renderFeatured();
    const shops = getFiltered();
    renderList(shops);
  }

  async function loadAndRender() {
    showSkeletons();
    render(); // render from cache immediately

    // Fetch fresh from server
    try {
      const raw = await API.getShops();
      if (raw.length) {
        Store.setServerShops(raw.map(API.normalize));
        render();
      }
    } catch (e) {
      // Stay on cached data — no error shown
    }
  }

  return {
    render, loadAndRender, buildCatBar,
    setCat, toggleNear, toggleOpen,
    onSearch, quickSearch, runSearch,
  };
})();
