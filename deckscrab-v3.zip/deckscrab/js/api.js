/**
 * api.js — All server communication in one place
 * Clean error handling. No server calls scattered across the app.
 */
const API = (() => {
  const BASE = 'https://deckscrab-backend-production.up.railway.app';
  const TIMEOUT = 10000; // 10s

  let _online = false;
  let _waking = false;

  // ── Core fetch with timeout + error handling ──
  async function req(method, path, body) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), TIMEOUT);
    try {
      const opts = {
        method,
        signal: ctrl.signal,
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      };
      if (body) opts.body = JSON.stringify(body);
      const res = await fetch(BASE + path, opts);
      clearTimeout(timer);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();
    } catch (err) {
      clearTimeout(timer);
      if (err.name === 'AbortError') throw new Error('Request timed out');
      throw err;
    }
  }

  const get  = path       => req('GET',    path);
  const post = (path, b)  => req('POST',   path, b);
  const patch = (path, b) => req('PATCH',  path, b);
  const del  = path       => req('DELETE', path);

  // ── Health check & wake ──
  async function ping() {
    try {
      const r = await get('/health');
      _online = !!(r && (r.status === 'ok' || r.uptime));
      return _online;
    } catch {
      _online = false;
      return false;
    }
  }

  async function wake() {
    if (_waking) return _online;
    _waking = true;
    for (let i = 0; i < 3; i++) {
      const ok = await ping();
      if (ok) { _waking = false; return true; }
      if (i < 2) await sleep(3500);
    }
    _waking = false;
    return false;
  }

  // ── Businesses ──
  async function getShops({ q = '', lat, lng, radius = 100, limit = 200 } = {}) {
    const params = new URLSearchParams({ limit });
    if (q)   params.set('q', q);
    if (lat) { params.set('lat', lat); params.set('lng', lng); params.set('radius', radius); }
    const data = await get(`/api/businesses?${params}`);
    return data?.businesses || [];
  }

  async function createShop(shop) {
    return post('/api/businesses', shop);
  }

  async function updateShop(id, patch_data) {
    return patch(`/api/businesses/${id}`, patch_data);
  }

  async function deleteShop(id) {
    return del(`/api/businesses/${id}`);
  }

  async function getShopBySlug(slug) {
    // Try exact ID first, then search by name
    const data = await get(`/api/businesses?limit=500`);
    const shops = data?.businesses || [];
    return shops.find(s =>
      slugify(s.name) === slug || loosify(s.name) === loosify(slug)
    ) || null;
  }

  // ── Orders ──
  async function createOrder(order) {
    return post('/api/orders', order);
  }

  async function getOrders({ shopPhone } = {}) {
    const params = new URLSearchParams({ limit: 200 });
    if (shopPhone) params.set('phone', shopPhone);
    const data = await get(`/api/orders?${params}`);
    return data?.orders || [];
  }

  async function updateOrderStatus(id, status) {
    return patch(`/api/orders/${id}`, { status, updatedAt: Date.now() });
  }

  // ── Analytics ──
  async function trackEvent(shopId, event) {
    try {
      await post('/api/analytics', { shopId, event, ts: Date.now() });
    } catch {} // Never throw on analytics
  }

  // ── Geocoding (Nominatim) ──
  async function geocode(query) {
    const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query)}&format=json&limit=5&accept-language=en`;
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 8000);
    try {
      const res = await fetch(url, {
        headers: { 'User-Agent': 'Deckscrab/2.0 (contact@deckscrab.in)', 'Accept-Language': 'en' },
        signal: ctrl.signal,
      });
      clearTimeout(timer);
      return await res.json();
    } catch {
      clearTimeout(timer);
      return [];
    }
  }

  async function reverseGeocode(lat, lng) {
    const url = `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json&zoom=16`;
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 8000);
    try {
      const res = await fetch(url, {
        headers: { 'User-Agent': 'Deckscrab/2.0 (contact@deckscrab.in)', 'Accept-Language': 'en' },
        signal: ctrl.signal,
      });
      clearTimeout(timer);
      const d = await res.json();
      const a = d.address || {};
      return {
        name: a.hamlet || a.suburb || a.neighbourhood || a.village || a.town || a.city || 'Your Location',
        city: a.city || a.town || a.village || '',
        pincode: a.postcode || '',
      };
    } catch {
      clearTimeout(timer);
      return { name: 'Your Location', city: '', pincode: '' };
    }
  }

  // ── Helpers ──
  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
  function slugify(name) {
    return (name || '').toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '').replace(/-+/g, '-').replace(/^-|-$/g, '');
  }
  function loosify(name) {
    return (name || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  }

  // ── Keep-alive ──
  let _keepAliveInterval = null;
  function startKeepAlive() {
    if (_keepAliveInterval) return;
    _keepAliveInterval = setInterval(async () => {
      if (!_online) await wake();
      else await ping();
    }, 4 * 60 * 1000);
  }

  // Normalize raw server business into app shape
  function normalize(b) {
    return {
      id:          b.id || b._id || b.bizId,
      bizId:       b.bizId || b.id,
      name:        b.name || 'Business',
      e:           b.sectorEmoji || '🏪',
      sectorEmoji: b.sectorEmoji || '🏪',
      sector:      b.sector || '',
      sectorName:  b.sectorName || b.sector || 'Local Business',
      g:           b.g || 'retail',
      desc:        b.description || '',
      addr:        b.address || '',
      city:        b.city || '',
      lat:         b.lat ? parseFloat(b.lat) : null,
      lng:         b.lng ? parseFloat(b.lng) : null,
      phone:       b.phone || '',
      wa:          b.whatsapp || b.phone || '',
      oh:          b.hours?.Monday?.open  || '09:00',
      oc:          b.hours?.Monday?.close || '21:00',
      rating:      parseFloat(b.rating) || 0,
      rc:          parseInt(b.reviewCount) || 0,
      views:       parseInt(b.views) || 1,
      verified:    !!b.verified,
      delivery:    !!b.delivery,
      price:       parseInt(b.priceLevel) || 2,
      prods:       (b.products || []).map(p => ({ n: p.name, p: parseFloat(p.price) || 0, emoji: p.emoji || '🍽️', cat: p.category || 'Menu', desc: p.description || '' })),
      photos:      b.photos || [],
      ownerUID:    b.ownerUID || '',
      reg:         b.registeredAt || 0,
      websiteTemplate: b.websiteTemplate || '',
      customHtml:  b.customHtml || '',
      websiteUrl:  b.websiteUrl || '',
      websiteEnabled: !!b.websiteEnabled,
    };
  }

  return {
    get isOnline() { return _online; },
    ping, wake, startKeepAlive,
    getShops, createShop, updateShop, deleteShop, getShopBySlug,
    createOrder, getOrders, updateOrderStatus,
    trackEvent,
    geocode, reverseGeocode,
    normalize, slugify,
  };
})();
