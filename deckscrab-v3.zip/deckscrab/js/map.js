/**
 * map.js — Shared map utilities
 * Core Leaflet map functionality shared between discover and detail.
 */
const MapUtils = (() => {

  const TILE_URL = 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png';
  const TILE_OPTS = { maxZoom: 20, subdomains: 'abcd' };

  function createMap(containerId, lat, lng, zoom = 14, opts = {}) {
    const el = document.getElementById(containerId);
    if (!el || typeof L === 'undefined') return null;

    const map = L.map(containerId, {
      zoomControl: opts.zoomControl ?? false,
      attributionControl: false,
      scrollWheelZoom: opts.scrollWheelZoom ?? false,
      dragging: opts.dragging ?? true,
      tap: true,
      tapTolerance: 15,
      preferCanvas: true,
      ...opts,
    }).setView([lat, lng], zoom);

    L.tileLayer(TILE_URL, TILE_OPTS).addTo(map);
    return map;
  }

  function shopMarker(shop, opts = {}) {
    const open  = Utils.isOpen(shop);
    const color = open ? Utils.sectorColor(shop) : '#9CA3AF';
    const emoji = shop.e || shop.sectorEmoji || '🏪';
    return L.divIcon({
      className: '',
      html: `<div style="
        background:${color};
        width:${opts.size || 40}px;
        height:${opts.size || 40}px;
        border-radius:50%;
        border:3px solid white;
        box-shadow:0 3px 10px rgba(0,0,0,.28);
        display:flex;
        align-items:center;
        justify-content:center;
        font-size:${opts.fontSize || 17}px
      ">${emoji}</div>`,
      iconSize: [opts.size || 40, opts.size || 40],
      iconAnchor: [opts.size / 2 || 20, opts.size / 2 || 20],
      popupAnchor: [0, -(opts.size / 2 || 24)],
    });
  }

  function userMarker() {
    return L.circleMarker;
  }

  function fitBounds(map, points, padding = [80, 60]) {
    if (!map || !points.length) return;
    try {
      if (points.length === 1) { map.setView(points[0], 16, { animate: true }); return; }
      map.fitBounds(L.latLngBounds(points), { padding, maxZoom: 16, animate: true });
    } catch {}
  }

  function invalidate(map, delays = [50, 200, 500]) {
    delays.forEach(t => setTimeout(() => map && map.invalidateSize({ pan: false }), t));
  }

  return { createMap, shopMarker, userMarker, fitBounds, invalidate };
})();
