/**
 * detail.js — Shop detail modal
 */
const DetailModule = (() => {
  let _miniMap = null;
  let _current = null;

  function open(id) {
    const shop = Store.allShops().find(s => s.id === id);
    if (!shop) return;
    _current = shop;

    const ov = Utils.el('shopDetailOv');
    if (!ov) return;

    renderHero(shop);
    renderBody(shop);

    ov.hidden = false;
    document.body.style.overflow = 'hidden';
    API.trackEvent(id, 'view');
    history.pushState({ modal: 'detail', shopId: id }, '', '');
  }

  function close() {
    const ov = Utils.el('shopDetailOv');
    if (ov) ov.hidden = true;
    document.body.style.overflow = '';
    if (_miniMap) { try { _miniMap.remove(); } catch {} _miniMap = null; }
    const hero = Utils.el('shopDetailHero');
    if (hero) { hero.querySelectorAll('.hero-emoji').forEach(e => e.remove()); }
    if (history.state?.modal === 'detail') history.back();
  }

  function renderHero(shop) {
    const hero = Utils.el('shopDetailHero');
    const body = Utils.el('shopDetailHeroBody');
    if (!hero || !body) return;

    const color = Utils.sectorColor(shop);
    hero.style.background = `linear-gradient(160deg, ${color}30, ${color}10)`;
    hero.querySelectorAll('.hero-emoji').forEach(e => e.remove());
    const emoEl = document.createElement('span');
    emoEl.className = 'hero-emoji';
    emoEl.style.cssText = 'font-size:72px;z-index:0;opacity:.6';
    emoEl.textContent = shop.e || shop.sectorEmoji || '🏪';
    hero.insertBefore(emoEl, hero.children[0]);

    const ov = document.createElement('div');
    ov.className = 'shop-detail-hero-overlay';
    hero.appendChild(ov);

    const open = Utils.isOpen(shop);
    const loc  = Store.location;
    const dist = loc && shop.lat && shop.lng ? Utils.km(loc.lat, loc.lng, +shop.lat, +shop.lng) : null;

    body.innerHTML = `
      <div class="shop-detail-name">${shop.name}</div>
      <div class="shop-detail-meta">
        <span style="color:${open ? '#4ade80' : '#f87171'};font-weight:700">${open ? '● Open' : '● Closed'}</span>
        ${shop.verified ? '<span style="color:#4ade80">✓ Verified</span>' : ''}
        <span>📍 ${[shop.addr, shop.city].filter(Boolean).join(', ')}</span>
        ${dist !== null ? `<span>${Utils.fmtDist(dist)} away</span>` : ''}
      </div>`;
  }

  function renderBody(shop) {
    const body = Utils.el('shopDetailBody');
    if (!body) return;
    const open = Utils.isOpen(shop);
    const loc  = Store.location;
    const dist = loc && shop.lat && shop.lng ? Utils.km(loc.lat, loc.lng, +shop.lat, +shop.lng) : null;
    const slug  = API.slugify(shop.name);
    const webUrl = shop.websiteUrl || `https://waseem-2007.github.io/deckscrab/?shop=${slug}`;
    const waMsg  = `Hi ${shop.name}! I saw your listing on Deckscrab. I'd like to know more.`;
    const waLink = shop.wa ? Utils.waLink(shop.wa, waMsg) : null;

    body.innerHTML = `
      <!-- Quick info -->
      <div class="quick-strip">
        ${shop.rating ? `<div class="qi">
          <div class="qi-label">Rating</div>
          <div class="qi-value">${Utils.starsHtml(shop.rating)} ${shop.rating}${shop.rc ? ` (${shop.rc})` : ''}</div>
        </div>` : ''}
        ${dist !== null ? `<div class="qi">
          <div class="qi-label">Distance</div>
          <div class="qi-value" style="color:var(--blue)">${Utils.fmtDist(dist)}</div>
        </div>` : ''}
        <div class="qi">
          <div class="qi-label">Price</div>
          <div class="qi-value" style="color:var(--flame)">${Utils.priceLevel(shop)}</div>
        </div>
        <div class="qi">
          <div class="qi-label">Type</div>
          <div class="qi-value" style="font-size:.78rem">${shop.sectorName || shop.sector || ''}</div>
        </div>
        ${shop.delivery ? `<div class="qi">
          <div class="qi-label">Delivery</div>
          <div class="qi-value" style="color:var(--forest)">✓ Yes</div>
        </div>` : ''}
      </div>

      <!-- Action buttons -->
      <div class="action-grid">
        ${waLink ? `<button class="action-btn action-btn--wa" onclick="window.open('${waLink}','_blank')">💬 Order on WhatsApp</button>` : ''}
        ${shop.phone ? `<button class="action-btn action-btn--call" onclick="window.open('tel:${shop.phone}')">📞 Call</button>` : ''}
        <button class="action-btn action-btn--map" onclick="DS.detail.navigate(DS.detail.current)">🧭 Directions</button>
        <button class="action-btn action-btn--share" onclick="Utils.shareShop(DS.detail.current)">🔗 Share</button>
      </div>

      <!-- Description -->
      ${shop.desc ? `<div style="font-family:'Bricolage Grotesque',sans-serif;font-size:.88rem;font-weight:700;color:var(--ink);margin:16px 0 8px">About</div>
      <div style="font-size:.82rem;color:var(--ink-3);line-height:1.75">${shop.desc}</div>` : ''}

      <!-- Menu/products -->
      ${shop.prods && shop.prods.length ? `
        <div style="font-family:'Bricolage Grotesque',sans-serif;font-size:.88rem;font-weight:700;color:var(--ink);margin:16px 0 8px">🛒 Products & Prices</div>
        <div style="background:var(--surface-2);border-radius:var(--radius-md);overflow:hidden;margin-bottom:16px">
          ${shop.prods.map(p => `
            <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 13px;border-bottom:1px solid var(--border)">
              <span style="font-size:.82rem;color:var(--ink)">${p.emoji || ''} ${p.n}</span>
              <span style="font-size:.85rem;font-weight:700;color:var(--flame)">₹${p.p}</span>
            </div>`).join('')}
        </div>` : ''}

      <!-- Website link -->
      <a href="${webUrl}" target="_blank" style="display:flex;align-items:center;gap:9px;background:var(--blue-soft);border:1.5px solid rgba(26,86,219,.2);border-radius:var(--radius-md);padding:11px 13px;text-decoration:none;margin:12px 0">
        <span style="font-size:1.1rem">🌐</span>
        <div style="flex:1;min-width:0">
          <div style="font-size:.76rem;font-weight:700;color:var(--blue)">Order Online</div>
          <div style="font-size:.66rem;color:rgba(26,86,219,.6);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${webUrl}</div>
        </div>
        <span style="font-size:.75rem;color:rgba(26,86,219,.5)">↗</span>
      </a>

      <!-- Mini map -->
      ${shop.lat && shop.lng ? `
        <div style="font-family:'Bricolage Grotesque',sans-serif;font-size:.88rem;font-weight:700;color:var(--ink);margin:16px 0 8px">📍 Location</div>
        <div id="shopMiniMap" style="height:140px;border-radius:var(--radius-md);border:1px solid var(--border);overflow:hidden;margin-bottom:16px"></div>` : ''}

      <!-- Reviews placeholder -->
      <div style="font-family:'Bricolage Grotesque',sans-serif;font-size:.88rem;font-weight:700;color:var(--ink);margin:16px 0 8px">⭐ Reviews</div>
      ${shop.rc ? `<div style="background:var(--surface-2);border-radius:var(--radius-md);padding:12px;font-size:.8rem;color:var(--ink-3)">${shop.rc} review${shop.rc !== 1 ? 's' : ''} · Avg ${shop.rating} ★</div>` :
        `<div style="font-size:.8rem;color:var(--ink-3);padding:12px 0">No reviews yet — be the first!</div>`}
    `;

    // Init mini map
    if (shop.lat && shop.lng) {
      setTimeout(() => initMiniMap(shop), 200);
    }
  }

  function initMiniMap(shop) {
    if (_miniMap) { try { _miniMap.remove(); } catch {} _miniMap = null; }
    const container = document.getElementById('shopMiniMap');
    if (!container || typeof L === 'undefined') return;

    _miniMap = L.map('shopMiniMap', { zoomControl: false, attributionControl: false, dragging: true, scrollWheelZoom: false }).setView([+shop.lat, +shop.lng], 16);
    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', { maxZoom: 20, subdomains: 'abcd' }).addTo(_miniMap);
    L.circleMarker([+shop.lat, +shop.lng], { radius: 12, fillColor: Utils.sectorColor(shop), fillOpacity: 1, color: 'white', weight: 3 }).addTo(_miniMap)
      .bindPopup(`<b>${shop.name}</b>`).openPopup();

    const loc = Store.location;
    if (loc) {
      L.circleMarker([loc.lat, loc.lng], { radius: 7, fillColor: '#FF4D00', fillOpacity: 1, color: 'white', weight: 2 }).addTo(_miniMap);
      L.polyline([[loc.lat, loc.lng], [+shop.lat, +shop.lng]], { color: '#FF4D00', weight: 2, dashArray: '5 5', opacity: 0.5 }).addTo(_miniMap);
      _miniMap.fitBounds([[loc.lat, loc.lng], [+shop.lat, +shop.lng]], { padding: [20, 20] });
    }
  }

  function navigate(shop) {
    if (!shop) return;
    let url;
    if (shop.lat && shop.lng && !isNaN(+shop.lat)) {
      const loc = Store.location;
      url = `https://www.google.com/maps/dir/?api=1&destination=${shop.lat},${shop.lng}&travelmode=driving`;
      if (loc) url += `&origin=${loc.lat},${loc.lng}`;
    } else {
      url = `https://www.google.com/maps/search/${encodeURIComponent(shop.name + ', ' + (shop.city || ''))}`;
    }
    window.open(url, '_blank');
    API.trackEvent(shop.id, 'navigate');
  }

  // Close on Escape
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') close();
  });

  // Close on back button
  window.addEventListener('popstate', e => {
    if (e.state?.modal !== 'detail') close();
  });

  return {
    open, close, navigate,
    get current() { return _current; },
  };
})();
