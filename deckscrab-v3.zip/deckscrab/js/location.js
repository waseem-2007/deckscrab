/**
 * location.js — Location detection and selection
 */
const LocationModule = (() => {
  let _acTimer;

  function openModal() {
    const ov = Utils.el('locModalOv');
    if (ov) { ov.hidden = false; Utils.el('locSearchInp')?.focus(); }
  }

  function closeModal() {
    const ov = Utils.el('locModalOv');
    if (ov) ov.hidden = true;
  }

  function pick(name, lat, lng) {
    Store.setLocation(lat, lng, name);
    const short = name.split(',')[0];
    Utils.el('locChipText').textContent = short;
    Utils.toast(`📍 ${short}`);
    closeModal();
    // Refresh views
    DS.home.render();
    if (DS.discover._map) DS.discover.render();
  }

  async function startGPS() {
    if (!navigator.geolocation) {
      Utils.toast('GPS not supported in this browser');
      return;
    }
    const btn   = Utils.el('gpsBtn');
    const icon  = Utils.el('gpsBtnIcon');
    const title = Utils.el('gpsBtnTitle');
    const sub   = Utils.el('gpsBtnSub');

    if (btn) btn.disabled = true;
    if (icon) icon.textContent = '⏳';
    if (title) title.textContent = 'Getting location…';

    navigator.geolocation.getCurrentPosition(
      async pos => {
        const { latitude: lat, longitude: lng } = pos.coords;
        if (icon)  icon.textContent  = '✅';
        if (title) title.textContent = 'Location found!';
        if (btn)   btn.disabled = false;

        const geo = await API.reverseGeocode(lat, lng);
        pick(geo.name, lat, lng);
      },
      err => {
        if (btn)   btn.disabled = false;
        if (icon)  icon.textContent  = '📡';
        if (title) title.textContent = 'Use My Current Location';
        if (sub)   sub.textContent   = 'Tap → allow → finds businesses near you';
        const msgs = {
          1: '❌ Allow location access in browser settings',
          2: '❌ GPS unavailable — type your city',
          3: '❌ GPS timed out — type your city',
        };
        Utils.toast(msgs[err.code] || '❌ GPS failed');
      },
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 0 }
    );
  }

  function autocomplete(query) {
    clearTimeout(_acTimer);
    const drop = Utils.el('locAcDrop');
    if (!drop) return;
    if (query.length < 2) { drop.innerHTML = ''; return; }

    _acTimer = setTimeout(async () => {
      const results = await API.geocode(query + ', India');
      drop.innerHTML = results.slice(0, 5).map(r => {
        const parts = (r.display_name || '').split(',');
        const name  = parts[0].trim();
        const sub   = parts.slice(1, 3).join(',').trim();
        const lat   = parseFloat(r.lat);
        const lng   = parseFloat(r.lon);
        return `<button class="loc-ac-item" onclick="DS.location.pick('${name.replace(/'/g, "\\'")}',${lat},${lng})">
          📍 <span><strong>${name}</strong>${sub ? `<span style="color:var(--ink-3);font-size:.76rem;margin-left:6px">${sub}</span>` : ''}</span>
        </button>`;
      }).join('');
    }, 300);
  }

  function doSearch() {
    const q = Utils.el('locSearchInp')?.value?.trim();
    if (!q) { Utils.toast('Type your city or area name'); return; }
    autocomplete(q + ' Tamil Nadu');
  }

  return { openModal, closeModal, pick, startGPS, autocomplete, doSearch };
})();
