/**
 * store.js — Centralized state management
 * Single source of truth. No scattered localStorage calls.
 */
const Store = (() => {
  // ── Keys ──
  const KEYS = {
    SHOPS:     'ds_shops_v3',
    ORDERS:    'ds_orders_v3',
    USER:      'ds_user_v2',
    LOCATION:  'ds_location_v2',
    CACHE_TS:  'ds_cache_ts',
    INSTALLED: 'ds_installed',
  };

  // ── In-memory state ──
  let state = {
    serverShops: [],
    localShops:  [],
    orders:      [],
    user:        null,       // { uid, name, email, photo, phone }
    location:    null,       // { lat, lng, name }
    catFilter:   '',
    searchQuery: '',
    nearMe:      false,
    openOnly:    false,
  };

  // ── Subscribers ──
  const listeners = {};
  function on(event, fn) {
    if (!listeners[event]) listeners[event] = [];
    listeners[event].push(fn);
  }
  function emit(event, data) {
    (listeners[event] || []).forEach(fn => fn(data));
  }

  // ── Persistence helpers ──
  function ls(key, val) {
    if (val === undefined) {
      try { return JSON.parse(localStorage.getItem(key)); } catch { return null; }
    }
    try { localStorage.setItem(key, JSON.stringify(val)); } catch (e) {
      // Storage full — evict oldest cache entries
      Object.keys(localStorage)
        .filter(k => k.startsWith('ds_cache_'))
        .forEach(k => localStorage.removeItem(k));
      try { localStorage.setItem(key, JSON.stringify(val)); } catch {}
    }
  }

  // ── Init ──
  function init() {
    state.localShops = ls(KEYS.SHOPS)  || [];
    state.orders     = ls(KEYS.ORDERS) || [];
    state.user       = ls(KEYS.USER)   || null;
    state.location   = ls(KEYS.LOCATION) || null;
  }

  // ── Shops ──
  function allShops() {
    // Deduplicate: server is authoritative. Local shops not on server are shown too.
    const seen = new Set();
    const result = [];
    const norm = n => (n || '').toLowerCase().replace(/[^a-z0-9]/g, '');

    state.serverShops.forEach(s => {
      const key = norm(s.name) + norm(s.city || s.addr || '').slice(0, 8);
      if (!seen.has(key)) { seen.add(key); result.push({ ...s, _src: 'server' }); }
    });

    state.localShops.forEach(s => {
      const key = norm(s.name) + norm(s.city || s.addr || '').slice(0, 8);
      if (!seen.has(key)) { seen.add(key); result.push({ ...s, _src: 'local' }); }
    });

    return result;
  }

  function myShops() {
    const user = state.user;
    if (!user) return state.localShops;
    return state.localShops.filter(s => {
      if (user.uid && s.ownerUID === user.uid) return true;
      if (user.phone) {
        const sp = (s.wa || s.phone || '').replace(/\D/g, '').slice(-10);
        return sp === user.phone.replace(/\D/g, '').slice(-10);
      }
      return false;
    });
  }

  function addLocalShop(shop) {
    // Prevent duplicate by name
    const norm = n => (n || '').toLowerCase().trim();
    const idx = state.localShops.findIndex(s => norm(s.name) === norm(shop.name));
    if (idx >= 0) {
      state.localShops[idx] = { ...state.localShops[idx], ...shop };
    } else {
      state.localShops.unshift(shop);
    }
    ls(KEYS.SHOPS, state.localShops);
    emit('shops-changed');
  }

  function deleteLocalShop(id) {
    state.localShops = state.localShops.filter(s => s.id !== id);
    ls(KEYS.SHOPS, state.localShops);
    emit('shops-changed');
  }

  function setServerShops(shops) {
    state.serverShops = shops;
    ls(KEYS.CACHE_TS, Date.now());
    emit('shops-changed');
  }

  // ── Location ──
  function setLocation(lat, lng, name) {
    state.location = { lat, lng, name };
    ls(KEYS.LOCATION, state.location);
    emit('location-changed', state.location);
  }

  // ── User ──
  function setUser(user) {
    state.user = user;
    ls(KEYS.USER, user);
    emit('user-changed', user);
  }
  function clearUser() { setUser(null); }
  function isLoggedIn() { return !!(state.user?.uid || state.user?.phone); }

  // ── Orders ──
  function addOrder(order) {
    state.orders.unshift(order);
    ls(KEYS.ORDERS, state.orders.slice(0, 200));
    emit('orders-changed');
  }
  function updateOrder(id, patch) {
    const idx = state.orders.findIndex(o => o.id === id);
    if (idx >= 0) {
      state.orders[idx] = { ...state.orders[idx], ...patch };
      ls(KEYS.ORDERS, state.orders);
      emit('orders-changed');
    }
  }
  function myOrders() {
    const phone = state.user?.phone;
    if (!phone) return state.orders;
    const p10 = phone.replace(/\D/g,'').slice(-10);
    return state.orders.filter(o => {
      const sp = (o.shopPhone || '').replace(/\D/g,'').slice(-10);
      return sp === p10 || sp.includes(p10);
    });
  }
  function pendingOrderCount() {
    return myOrders().filter(o => o.status === 'pending').length;
  }

  // ── Filters ──
  function setFilter(key, val) {
    state[key] = val;
    emit('filter-changed', { key, val });
  }

  // ── Cache validation ──
  function isCacheStale(maxAgeMs = 5 * 60 * 1000) {
    const ts = ls(KEYS.CACHE_TS) || 0;
    return Date.now() - ts > maxAgeMs;
  }

  return {
    init, on, emit,
    get state() { return state; },
    allShops, myShops,
    addLocalShop, deleteLocalShop, setServerShops,
    setLocation, setUser, clearUser, isLoggedIn,
    addOrder, updateOrder, myOrders, pendingOrderCount,
    setFilter, isCacheStale,
    // direct state access for reads
    get location() { return state.location; },
    get user() { return state.user; },
  };
})();
