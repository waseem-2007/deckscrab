/**
 * nav.js — Page routing and navigation
 */
const NavModule = (() => {
  const PAGES = ['home', 'discover', 'addshop', 'grow', 'profile'];
  let _current = 'home';

  function go(page, pushState = true) {
    if (!PAGES.includes(page)) page = 'home';

    // Update browser history
    if (pushState) {
      try {
        const url = `?page=${page}`;
        if (history.state?.page !== page) history.pushState({ page }, '', url);
        else history.replaceState({ page }, '', url);
      } catch {}
    }

    // Deactivate all pages + nav buttons
    PAGES.forEach(p => {
      document.getElementById('page-' + p)?.classList.remove('active');
      const btn = document.getElementById('bnav-' + p);
      if (btn) { btn.classList.remove('active'); btn.removeAttribute('aria-current'); }
    });

    // Activate target
    document.getElementById('page-' + page)?.classList.add('active');
    const navBtn = document.getElementById('bnav-' + page);
    if (navBtn) { navBtn.classList.add('active'); navBtn.setAttribute('aria-current', 'page'); }

    _current = page;

    // Page-specific init
    switch (page) {
      case 'home':     DS.home.loadAndRender();   break;
      case 'discover': DS.discover.init();         break;
      case 'addshop':  DS.addshop.init();          break;
      case 'grow':     DS.grow.render();           break;
      case 'profile':  DS.profile.render();        break;
    }

    window.scrollTo({ top: 0, behavior: 'instant' });
  }

  function init() {
    // Back/forward navigation
    window.addEventListener('popstate', e => {
      const page = e.state?.page || 'home';
      go(page, false);
    });

    // Read initial page from URL
    const params = new URLSearchParams(location.search);
    const initPage = params.get('page') || 'home';
    try { history.replaceState({ page: initPage }, '', '?page=' + initPage); } catch {}
    go(initPage, false);
  }

  return {
    go, init,
    get current() { return _current; },
  };
})();
