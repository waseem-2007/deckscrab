/**
 * app.js — Application bootstrap
 */

// Global namespace
window.DS = {
  store:    Store,
  home:     HomeModule,
  discover: DiscoverModule,
  detail:   DetailModule,
  addshop:  AddShopModule,
  profile:  ProfileModule,
  grow:     GrowModule,
  nav:      NavModule,
  location: LocationModule,
};
window.Utils = Utils;
window.API   = API;
window.Store = Store;

// Firebase (optional)
window._fbAuth = null;
(function loadFirebase() {
  const PAIRS = [
    ['https://www.gstatic.com/firebasejs/10.7.1/firebase-app-compat.js',
     'https://www.gstatic.com/firebasejs/10.7.1/firebase-auth-compat.js'],
    ['https://cdnjs.cloudflare.com/ajax/libs/firebase/10.7.1/firebase-app-compat.min.js',
     'https://cdnjs.cloudflare.com/ajax/libs/firebase/10.7.1/firebase-auth-compat.min.js'],
  ];
  const FB_CONFIG = { apiKey:'AIzaSyCFk8s4uK_Me-JLebi-TcJ1dgILESj-4L8', authDomain:'deckscrab.firebaseapp.com', projectId:'deckscrab' };
  function tryPair(i) {
    if (i >= PAIRS.length) return;
    const s1 = document.createElement('script');
    s1.src = PAIRS[i][0];
    s1.onerror = () => tryPair(i + 1);
    s1.onload  = () => {
      const s2 = document.createElement('script');
      s2.src = PAIRS[i][1];
      s2.onerror = () => tryPair(i + 1);
      s2.onload  = () => {
        try {
          if (!firebase.apps.length) firebase.initializeApp(FB_CONFIG);
          window._fbAuth = firebase.auth();
          window._fbAuth.onAuthStateChanged(user => {
            if (user && !Store.user?.uid) {
              Store.setUser({ uid: user.uid, name: user.displayName||'', email: user.email||'', photo: user.photoURL||'' });
            }
          });
        } catch {}
      };
      document.head.appendChild(s2);
    };
    document.head.appendChild(s1);
  }
  tryPair(0);
})();

// Connectivity
function updateNetStatus() {
  const bar = Utils.el('offlineBanner');
  if (bar) bar.hidden = navigator.onLine;
}
window.addEventListener('online',  () => { updateNetStatus(); DS.home.loadAndRender(); Utils.toast('✅ Back online'); });
window.addEventListener('offline', () => { updateNetStatus(); Utils.toast('📡 Offline — cached data shown', 4000); });

// Pull-to-refresh
let _pty = 0;
document.addEventListener('touchstart', e => { if (window.scrollY===0) _pty = e.touches[0].clientY; }, { passive:true });
document.addEventListener('touchend',   e => {
  if (_pty > 0 && (e.changedTouches[0].clientY - _pty) > 72) {
    if (DS.nav.current === 'home')     { DS.home.loadAndRender(); Utils.toast('🔄 Refreshed'); }
    if (DS.nav.current === 'discover') { DS.discover.render();    Utils.toast('🔄 Refreshed'); }
  }
  _pty = 0;
}, { passive:true });

// Service worker
if ('serviceWorker' in navigator && location.hostname === 'waseem-2007.github.io') {
  window.addEventListener('load', () => navigator.serviceWorker.register('/deckscrab/sw.js', { scope:'/deckscrab/' }).catch(()=>{}));
}

// Boot
document.addEventListener('DOMContentLoaded', () => {
  updateNetStatus();
  Store.init();
  DS.nav.init();
  API.wake().then(ok => { if (ok) DS.home.loadAndRender(); });
  API.startKeepAlive();
  const loc = Store.location;
  if (loc) Utils.setText('locChipText', (loc.name||'').split(',')[0] || 'Location set');
});
