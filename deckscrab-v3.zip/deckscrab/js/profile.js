/**
 * profile.js — Profile page
 */
const ProfileModule = (() => {

  function render() {
    const c = Utils.el('profileContent');
    if (!c) return;
    Store.isLoggedIn() ? renderProfile(c) : renderSignIn(c);
  }

  function renderSignIn(c) {
    c.innerHTML = `
      <div style="padding:16px">
        <div class="signin-card">
          <div class="signin-icon">🔐</div>
          <div class="signin-title">Sign in to Deckscrab</div>
          <div class="signin-sub">Manage your shops, track orders, and access your business dashboard from any device.</div>
          <button class="google-btn" onclick="DS.profile.googleSignIn()">
            <svg width="20" height="20" viewBox="0 0 24 24"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>
            Continue with Google
          </button>
          <div style="font-size:.72rem;color:var(--ink-4);margin-bottom:14px;text-align:center">— or use phone number —</div>
          <div class="phone-signin-row">
            <input id="phoneSignInInp" class="field-input" type="tel" placeholder="10-digit WhatsApp number" style="flex:1"/>
            <button class="btn-primary" onclick="DS.profile.phoneSignIn()">Go →</button>
          </div>
        </div>
      </div>`;
  }

  function renderProfile(c) {
    const user   = Store.user;
    const shops  = Store.myShops();
    const pending = Store.pendingOrderCount();

    c.innerHTML = `
      <div class="profile-hero">
        <div class="profile-hero-bg">${shops[0]?.e || '👤'}</div>
        <div class="profile-hero-overlay"></div>
        <div class="profile-hero-content">
          <div class="profile-name">
            ${user?.photo ? `<img loading="lazy" src="${user.photo}" width="34" height="34" style="border-radius:50%;border:2px solid rgba(255,255,255,.3)" referrerpolicy="no-referrer"/>` : ''}
            ${user?.name || (shops[0] ? shops[0].e + ' ' + shops[0].name : 'My Profile')}
          </div>
          <div class="profile-sub">${user?.email || ''}${user?.phone ? '  ·  +91 ' + user.phone : ''}</div>
          ${pending ? `<div style="margin-top:8px;display:inline-flex;align-items:center;gap:5px;background:rgba(239,68,68,.2);border-radius:var(--radius-full);padding:3px 11px;font-size:.72rem;font-weight:700;color:#fca5a5">📦 ${pending} order${pending !== 1 ? 's' : ''} pending</div>` : ''}
        </div>
      </div>

      <div class="profile-body">
        ${shops.length ? `
          <div class="profile-stats">
            <div class="profile-stat"><div class="profile-stat-n">👁 ${shops.reduce((a, s) => a + (s.views || 1), 0)}</div><div class="profile-stat-l">Views</div></div>
            <div class="profile-stat"><div class="profile-stat-n">🏪 ${shops.length}</div><div class="profile-stat-l">Shops</div></div>
            <div class="profile-stat"><div class="profile-stat-n">📦 ${Store.myOrders().length}</div><div class="profile-stat-l">Orders</div></div>
          </div>` : ''}

        <!-- Upgrade card -->
        <div style="background:var(--ink);border-radius:var(--radius-lg);padding:16px;display:flex;align-items:center;gap:12px;margin-bottom:14px">
          <span style="font-size:1.8rem;flex-shrink:0">🚀</span>
          <div style="flex:1">
            <div style="font-family:var(--font-display);font-size:.9rem;font-weight:700;color:white;margin-bottom:2px">Get Your Website + Bot</div>
            <div style="font-size:.72rem;color:rgba(255,255,255,.5)">24/7 ordering. Auto WhatsApp alerts. ₹399/mo.</div>
          </div>
          <button onclick="DS.nav.go('grow')" style="background:var(--flame);color:white;border:none;border-radius:var(--radius-md);padding:8px 14px;font-size:.77rem;font-weight:700;flex-shrink:0;cursor:pointer">Upgrade</button>
        </div>

        <!-- Menu -->
        <div class="profile-menu">
          <div class="profile-menu-item" onclick="DS.profile.showOrders()"><span class="pmi-left">📦 My Orders${pending ? ` <span style="background:var(--rose);color:white;border-radius:10px;padding:1px 7px;font-size:.6rem">${pending}</span>` : ''}</span><span class="pmi-arrow">›</span></div>
          <div class="profile-menu-item" onclick="DS.profile.showShops()"><span class="pmi-left">🏪 My Listed Shops</span><span class="pmi-arrow">›</span></div>
          <div class="profile-menu-item" onclick="DS.profile.syncShops()"><span class="pmi-left">☁️ Sync to Server</span><span class="pmi-arrow">›</span></div>
          <div class="profile-menu-item" onclick="DS.nav.go('addshop')"><span class="pmi-left">➕ Add New Business</span><span class="pmi-arrow">›</span></div>
          <div class="profile-menu-item" onclick="DS.location.openModal()"><span class="pmi-left">📍 Set My Location</span><span class="pmi-arrow">›</span></div>
          <div class="profile-menu-item" onclick="DS.profile.signOut()"><span class="pmi-left" style="color:var(--rose)">🚪 Sign Out</span><span class="pmi-arrow">›</span></div>
        </div>

        <div id="profileShopsSection"></div>
      </div>`;
  }

  function showShops() {
    const sec = Utils.el('profileShopsSection');
    if (!sec) return;
    sec.scrollIntoView({ behavior: 'smooth', block: 'start' });
    const shops = Store.myShops();

    if (!shops.length) {
      sec.innerHTML = `<div style="text-align:center;padding:32px 20px">
        <div style="font-size:2.5rem;margin-bottom:12px">🏪</div>
        <div style="font-family:var(--font-display);font-size:1rem;font-weight:700;color:var(--ink);margin-bottom:6px">No Shops Yet</div>
        <div style="font-size:.8rem;color:var(--ink-3);margin-bottom:18px">Register your first shop free — takes 60 seconds.</div>
        <button class="btn-primary" onclick="DS.nav.go('addshop')">+ Register Shop</button>
      </div>`;
      return;
    }

    sec.innerHTML = `<div style="font-family:var(--font-display);font-size:.98rem;font-weight:700;color:var(--ink);margin:16px 0 12px">🏪 My Listed Shops</div>` +
      shops.map(s => {
        const slug   = API.slugify(s.name);
        const webUrl = s.websiteUrl || `https://waseem-2007.github.io/deckscrab/?shop=${slug}`;
        return `
          <div class="my-shop-card">
            <div class="my-shop-banner" style="background:linear-gradient(135deg,${Utils.sectorColor(s)}40,${Utils.sectorColor(s)}10)">
              <span style="font-size:2.2rem">${s.e || '🏪'}</span>
              <div class="my-shop-live">🟢 LIVE</div>
            </div>
            <div class="my-shop-body">
              <div class="my-shop-name">${s.name}</div>
              <div class="my-shop-cat">${s.sectorName || s.sector || ''}</div>
              <div style="font-size:.7rem;color:var(--ink-3);margin-bottom:8px">📍 ${[s.addr, s.city].filter(Boolean).join(', ')}</div>
              <div style="background:var(--surface-2);border-radius:var(--radius-sm);padding:9px 11px;margin-bottom:10px">
                <div style="font-size:.66rem;color:var(--ink-4);margin-bottom:4px">🌐 Your website link</div>
                <div style="font-size:.69rem;color:var(--blue);word-break:break-all;margin-bottom:7px">${webUrl}</div>
                <div style="display:flex;gap:5px">
                  <a href="${webUrl}" target="_blank" style="background:var(--blue);color:white;border-radius:6px;padding:5px 10px;font-size:.68rem;font-weight:700;text-decoration:none">🌐 Open</a>
                  <button onclick="navigator.clipboard?.writeText('${webUrl}').then(()=>Utils.toast('✅ Link copied!'))" style="background:var(--surface-2);border:1px solid var(--border-2);color:var(--ink-2);border-radius:6px;padding:5px 10px;font-size:.68rem;font-weight:700;cursor:pointer">📋 Copy</button>
                  <button onclick="Utils.shareShop(${JSON.stringify({ name: s.name, addr: s.addr, city: s.city }).replace(/'/g, "\\'")})" style="background:linear-gradient(135deg,#25D366,#128C7E);color:white;border:none;border-radius:6px;padding:5px 10px;font-size:.68rem;font-weight:700;cursor:pointer">💬 Share</button>
                </div>
              </div>
              <div class="my-shop-actions">
                <button class="my-shop-btn my-shop-btn--view" onclick="DS.detail.open('${s.id}')">👁 View</button>
                <button class="my-shop-btn my-shop-btn--boost" onclick="DS.nav.go('grow')">🚀 Boost</button>
                <button class="my-shop-btn my-shop-btn--del" onclick="DS.profile.deleteShop('${s.id}')">🗑 Delete</button>
              </div>
            </div>
          </div>`;
      }).join('');
  }

  function showOrders() {
    const sec = Utils.el('profileShopsSection');
    if (!sec) return;
    sec.scrollIntoView({ behavior: 'smooth', block: 'start' });
    const orders = Store.myOrders();

    if (!orders.length) {
      sec.innerHTML = `<div style="text-align:center;padding:32px 20px">
        <div style="font-size:2.5rem;margin-bottom:12px">📦</div>
        <div style="font-family:var(--font-display);font-size:1rem;font-weight:700;color:var(--ink);margin-bottom:6px">No Orders Yet</div>
        <div style="font-size:.8rem;color:var(--ink-3)">When customers order via WhatsApp, they appear here.</div>
      </div>`;
      return;
    }

    const STATUS = { confirmed: { l: '✅ Confirmed', c: 'var(--forest)' }, rejected: { l: '❌ Rejected', c: 'var(--rose)' }, pending: { l: '🔴 Pending', c: 'var(--amber)' } };

    sec.innerHTML = `<div style="font-family:var(--font-display);font-size:.98rem;font-weight:700;color:var(--ink);margin:16px 0 12px">📦 Recent Orders</div>` +
      orders.slice(0, 30).map(o => {
        const st = STATUS[o.status] || STATUS.pending;
        return `
          <div style="background:var(--surface-1);border:1px solid var(--border-2);border-radius:var(--radius-md);padding:13px;margin-bottom:9px;box-shadow:var(--shadow-sm)">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px">
              <div>
                <div style="font-family:var(--font-mono);font-size:.75rem;font-weight:700;color:var(--blue)">#${o.orderId || o.id?.slice(-6) || '——'}</div>
                <div style="font-size:.67rem;color:var(--ink-3);margin-top:2px">⏰ ${new Date(o.ts || o.createdAt || Date.now()).toLocaleDateString('en-IN',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'})}</div>
              </div>
              <div style="text-align:right">
                <div style="font-family:var(--font-display);font-size:1rem;font-weight:800;color:var(--flame)">₹${o.total || '—'}</div>
                <div style="font-size:.65rem;font-weight:700;color:${st.c}">${st.l}</div>
              </div>
            </div>
            ${o.custName ? `<div style="font-size:.76rem;color:var(--ink-2)">👤 ${o.custName}${o.custPhone ? '  ·  📞 +91 ' + o.custPhone : ''}</div>` : ''}
            ${o.items?.length ? `<div style="font-size:.72rem;color:var(--ink-3);margin-top:4px">${o.items.map(i => i.name || i.n).join(', ')}</div>` : ''}
          </div>`;
      }).join('');
  }

  async function syncShops() {
    const shops = Store.myShops();
    if (!shops.length) { Utils.toast('No shops to sync'); return; }
    Utils.toast('☁️ Syncing…');
    let ok = 0;
    for (const s of shops) {
      try { const r = await API.createShop(s); if (r?.ok || r?.id) ok++; } catch {}
    }
    Utils.toast(ok > 0 ? `✅ ${ok} shop${ok !== 1 ? 's' : ''} synced!` : '❌ Sync failed — check connection');
    if (ok > 0) DS.home.loadAndRender();
  }

  async function deleteShop(id) {
    if (!confirm('Delete this listing? Cannot be undone.')) return;
    const shop = Store.myShops().find(s => s.id === id);
    Store.deleteLocalShop(id);
    if (shop?.bizId) try { await API.deleteShop(shop.bizId); } catch {}
    Utils.toast('🗑️ Deleted');
    render();
  }

  function googleSignIn() {
    if (window._fbAuth) {
      try {
        const provider = new firebase.auth.GoogleAuthProvider();
        window._fbAuth.signInWithPopup(provider).then(r => {
          Store.setUser({ uid: r.user.uid, name: r.user.displayName, email: r.user.email, photo: r.user.photoURL });
          render();
          Utils.toast('✅ Signed in as ' + r.user.displayName);
        }).catch(() => Utils.toast('⚠️ Google sign-in failed — use phone number'));
      } catch { Utils.toast('⚠️ Use phone number instead'); }
    } else {
      Utils.toast('⚠️ Firebase not loaded — use phone number');
    }
  }

  function phoneSignIn() {
    const phone = (Utils.el('phoneSignInInp')?.value || '').replace(/\D/g, '').slice(-10);
    if (phone.length !== 10) { Utils.toast('⚠️ Enter a valid 10-digit number'); return; }
    Store.setUser({ uid: 'phone_' + phone, phone, name: 'Shop Owner', email: '' });
    render();
    Utils.toast('✅ Signed in with +91 ' + phone);
  }

  function signOut() {
    if (!confirm('Sign out?')) return;
    Store.clearUser();
    if (window._fbAuth) window._fbAuth.signOut().catch(() => {});
    render();
    Utils.toast('👋 Signed out');
  }

  return { render, showShops, showOrders, syncShops, deleteShop, googleSignIn, phoneSignIn, signOut };
})();
