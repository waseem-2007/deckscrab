/**
 * grow.js — Grow page (pricing plans + website builder intro)
 */
const GrowModule = (() => {

  function render() {
    const c = Utils.el('growContent');
    if (!c) return;
    c.innerHTML = `
      <div class="grow-hero">
        <div class="grow-hero-pill">🚀 Business Growth</div>
        <h2 class="grow-hero-title">Your Shop Gets a<br/><span>Real Website</span></h2>
        <p class="grow-hero-sub">Customers browse your menu, order, and pay online. You get a WhatsApp notification instantly. Set up in minutes.</p>
      </div>

      <div class="plans-wrap">
        ${plan({
          icon: '🌐',
          name: 'Website + Bot',
          price: 399,
          popular: true,
          desc: 'Your own ordering website — customers browse, order, pay and you get auto-notified on WhatsApp.',
          features: [
            'Your own ordering website',
            'yourshop.deckscrab.in link',
            'Full product menu with prices',
            'UPI · Card · Cash payments',
            'Auto WhatsApp order alerts',
            'GST bill generation',
            'OTP customer verification',
          ],
          ctaText: '🚀 Get Website — Free Trial',
          waMsg: 'Hi! I want the Website + Bot plan (₹399/mo) for my shop on Deckscrab.',
        })}
        ${plan({
          icon: '📣',
          name: 'Ads & Boost',
          price: 999,
          popular: false,
          desc: 'Push your listing to the top of search results and home page. Shown first to nearby customers.',
          features: [
            'Priority on home page',
            'Top of search results',
            'Featured map pin',
            'Push notifications to users',
            'Weekly analytics report',
            'Location targeting',
            'Verified badge ✓',
          ],
          ctaText: '📣 Start Boosting',
          waMsg: 'Hi! I want the Ads & Boost plan (₹999/mo) for my shop on Deckscrab.',
        })}

        <!-- WhatsApp CTA -->
        <div style="background:linear-gradient(135deg,rgba(37,211,102,.1),rgba(7,94,84,.12));border:1.5px solid rgba(37,211,102,.25);border-radius:var(--radius-xl);padding:22px;text-align:center;margin-bottom:20px">
          <div style="font-size:1.8rem;margin-bottom:10px">💬</div>
          <div style="font-family:var(--font-display);font-size:1.1rem;font-weight:800;color:var(--ink);margin-bottom:6px">Have Questions?</div>
          <div style="font-size:.82rem;color:var(--ink-3);line-height:1.7;margin-bottom:16px;max-width:280px;margin-left:auto;margin-right:auto">Chat directly with us on WhatsApp. We'll help set up your website personally — no tech skills needed.</div>
          <button
            onclick="window.open('https://wa.me/919384707706?text='+encodeURIComponent('Hi Deckscrab! I want to grow my business. Can you help?'),'_blank')"
            style="background:#25D366;color:white;border:none;border-radius:var(--radius-full);padding:13px 26px;font-size:.9rem;font-weight:800;cursor:pointer;display:inline-flex;align-items:center;gap:8px"
          >💬 Chat — 9384707706</button>
        </div>

        <!-- FAQ -->
        <div style="font-family:var(--font-display);font-size:.97rem;font-weight:700;color:var(--ink);margin-bottom:12px">Common Questions</div>
        ${[
          ['How fast will my website go live?', 'Within 2 hours of payment. We set it up for you, no tech skills needed.'],
          ['Is the free listing really free?', 'Yes! Basic listing (what you already have) is 100% free forever. Website & Ads are paid extras.'],
          ['Can I cancel anytime?', 'Yes, cancel anytime via WhatsApp. No contracts, no lock-in.'],
          ['What payment methods do you accept?', 'UPI (GPay, PhonePe, PayTM), Net Banking, and Cash via agent.'],
        ].map(([q, a]) => `
          <details style="background:var(--surface-1);border:1px solid var(--border-2);border-radius:var(--radius-md);margin-bottom:8px;overflow:hidden">
            <summary style="padding:13px 14px;font-size:.84rem;font-weight:600;color:var(--ink);cursor:pointer;list-style:none;display:flex;justify-content:space-between;align-items:center">
              ${q} <span style="color:var(--ink-3);font-size:.9rem">+</span>
            </summary>
            <div style="padding:0 14px 13px;font-size:.8rem;color:var(--ink-3);line-height:1.7">${a}</div>
          </details>`).join('')}
      </div>`;
  }

  function plan({ icon, name, price, popular, desc, features, ctaText, waMsg }) {
    return `
      <div class="plan-card ${popular ? 'plan-card--featured' : ''}">
        ${popular ? `<div class="plan-featured-badge">⭐ Most Popular</div>` : ''}
        <div style="${popular ? 'padding-top:8px' : ''}">
          <div class="plan-icon">${icon}</div>
          <div class="plan-name">${name}</div>
          <div class="plan-desc">${desc}</div>
          <div class="plan-price">₹${price}<sub>/month</sub></div>
          <ul class="plan-features">
            ${features.map(f => `<li>${f}</li>`).join('')}
          </ul>
          <button
            class="plan-btn ${popular ? 'plan-btn--flame' : 'plan-btn--ghost'}"
            onclick="window.open('https://wa.me/919384707706?text='+encodeURIComponent('${waMsg}'),'_blank')"
          >${ctaText}</button>
        </div>
      </div>`;
  }

  return { render };
})();
