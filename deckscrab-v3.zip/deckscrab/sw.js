/**
 * sw.js — Service Worker for offline-first caching
 */
const CACHE_NAME = 'deckscrab-v3';
const STATIC_ASSETS = [
  '/deckscrab/',
  '/deckscrab/index.html',
  '/deckscrab/css/reset.css',
  '/deckscrab/css/tokens.css',
  '/deckscrab/css/layout.css',
  '/deckscrab/css/components.css',
  '/deckscrab/css/pages.css',
  '/deckscrab/css/animations.css',
  '/deckscrab/js/store.js',
  '/deckscrab/js/api.js',
  '/deckscrab/js/utils.js',
  '/deckscrab/js/location.js',
  '/deckscrab/js/map.js',
  '/deckscrab/js/home.js',
  '/deckscrab/js/discover.js',
  '/deckscrab/js/detail.js',
  '/deckscrab/js/addshop.js',
  '/deckscrab/js/profile.js',
  '/deckscrab/js/grow.js',
  '/deckscrab/js/nav.js',
  '/deckscrab/js/app.js',
];

// Install — pre-cache static shell
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE_NAME).then(c => c.addAll(STATIC_ASSETS)).then(() => self.skipWaiting())
  );
});

// Activate — remove old caches
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// Fetch — network-first for API, cache-first for assets
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);

  // API calls — network only (or network with cached fallback for /api/businesses)
  if (url.hostname.includes('railway.app') || url.hostname.includes('nominatim')) {
    e.respondWith(
      fetch(e.request).catch(() => new Response('{"error":"offline"}', { headers: { 'Content-Type': 'application/json' } }))
    );
    return;
  }

  // Leaflet tiles — cache-first
  if (url.hostname.includes('cartocdn') || url.hostname.includes('openstreetmap')) {
    e.respondWith(
      caches.open('ds-tiles-v1').then(c =>
        c.match(e.request).then(hit => hit || fetch(e.request).then(res => {
          if (res.ok) c.put(e.request, res.clone());
          return res;
        }))
      )
    );
    return;
  }

  // Static app assets — stale-while-revalidate
  e.respondWith(
    caches.open(CACHE_NAME).then(c =>
      c.match(e.request).then(hit => {
        const fetchPromise = fetch(e.request).then(res => {
          if (res.ok && e.request.method === 'GET') c.put(e.request, res.clone());
          return res;
        }).catch(() => null);
        return hit || fetchPromise;
      })
    )
  );
});
